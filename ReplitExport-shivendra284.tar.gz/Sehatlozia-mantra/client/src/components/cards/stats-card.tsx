import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string;
  subtitle: string;
  progress: number;
  icon: string;
  color: "primary" | "blue" | "purple" | "accent";
}

const colorMap = {
  primary: {
    bg: "bg-primary/10",
    progress: "bg-primary",
    text: "text-primary"
  },
  blue: {
    bg: "bg-blue-100",
    progress: "bg-blue-500",
    text: "text-blue-500"
  },
  purple: {
    bg: "bg-purple-100",
    progress: "bg-purple-500",
    text: "text-purple-500"
  },
  accent: {
    bg: "bg-accent/10",
    progress: "bg-accent",
    text: "text-accent"
  }
};

export function StatsCard({ title, value, subtitle, progress, icon, color }: StatsCardProps) {
  const colors = colorMap[color];
  
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-2xl font-bold text-gray-800">{value}</p>
            <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
          </div>
          <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center text-xl", colors.bg, colors.text)}>
            {icon}
          </div>
        </div>
        <div className="mt-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className={cn("h-2 rounded-full transition-all duration-300", colors.progress)} 
              style={{ width: `${Math.min(progress, 100)}%` }}
            ></div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
