import { Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend);

interface NutritionChartProps {
  data: {
    carbs: number;
    protein: number;
    fat: number;
  };
}

export function NutritionChart({ data }: NutritionChartProps) {
  const chartData = {
    labels: ['Carbs', 'Protein', 'Fat'],
    datasets: [
      {
        data: [data.carbs, data.protein, data.fat],
        backgroundColor: [
          'hsl(216.8421 87.2340% 64.5098%)', // Blue
          'hsl(158.7234 64.4068% 52.1569%)', // Green/Primary
          'hsl(42.0290 92.8251% 56.2745%)',  // Accent/Yellow
        ],
        borderWidth: 0,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          font: {
            family: 'Inter',
            size: 12,
          },
        },
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.label}: ${Math.round(context.parsed)}g`;
          },
        },
      },
    },
  };

  return (
    <div className="h-64 w-full">
      <Doughnut data={chartData} options={options} />
    </div>
  );
}
