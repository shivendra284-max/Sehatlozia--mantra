import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Search, Plus } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Food } from "@shared/schema";

interface FoodSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

export function FoodSearch({ isOpen, onClose }: FoodSearchProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFood, setSelectedFood] = useState<Food | null>(null);
  const [quantity, setQuantity] = useState("1");
  const [mealType, setMealType] = useState("breakfast");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const today = format(new Date(), 'yyyy-MM-dd');

  const { data: foods, isLoading } = useQuery({
    queryKey: ['/api/foods', searchQuery],
    queryFn: async () => {
      const url = searchQuery 
        ? `/api/foods?search=${encodeURIComponent(searchQuery)}`
        : '/api/foods';
      const res = await fetch(url);
      return res.json();
    },
    enabled: isOpen
  });

  const logFoodMutation = useMutation({
    mutationFn: async (logData: { foodId: string; quantity: number; mealType: string }) => {
      await apiRequest('POST', '/api/food-logs', logData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/food-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Food logged successfully!",
        description: "Your meal has been added to today's log.",
      });
      onClose();
      resetForm();
    }
  });

  const resetForm = () => {
    setSearchQuery("");
    setSelectedFood(null);
    setQuantity("1");
    setMealType("breakfast");
  };

  const handleLogFood = () => {
    if (!selectedFood) return;
    
    logFoodMutation.mutate({
      foodId: selectedFood.id,
      quantity: parseFloat(quantity),
      mealType
    });
  };

  const filteredFoods = foods || [];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Log Food</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search Indian foods... (e.g., rajma, dal, biryani)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-food-search"
            />
          </div>

          {/* Food Selection */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-800">Select Food</h3>
            {isLoading ? (
              <div className="grid grid-cols-1 gap-2">
                {Array(3).fill(0).map((_, i) => (
                  <div key={i} className="h-16 bg-gray-100 rounded-lg animate-pulse"></div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto">
                {filteredFoods.map((food: Food) => (
                  <button
                    key={food.id}
                    onClick={() => setSelectedFood(food)}
                    className={`p-3 text-left rounded-lg border transition-colors ${
                      selectedFood?.id === food.id
                        ? 'border-primary bg-primary/5'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    data-testid={`food-item-${food.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-gray-800">{food.name}</h4>
                        {food.nameHindi && (
                          <p className="text-sm text-gray-500">{food.nameHindi}</p>
                        )}
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="secondary" className="text-xs">
                            {food.category}
                          </Badge>
                          {food.isIndian && (
                            <Badge variant="outline" className="text-xs border-orange-200 text-orange-600">
                              Indian
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{food.calories} cal</p>
                        <p className="text-xs text-gray-500">{food.servingSize}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2 mt-2 text-xs text-gray-600">
                      <span>C: {food.carbs}g</span>
                      <span>P: {food.protein}g</span>
                      <span>F: {food.fat}g</span>
                      <span>Fb: {food.fiber}g</span>
                    </div>
                  </button>
                ))}
                
                {filteredFoods.length === 0 && searchQuery && (
                  <div className="text-center py-8 text-gray-500">
                    <Search className="w-8 h-8 mx-auto mb-2 opacity-20" />
                    <p>No foods found for "{searchQuery}"</p>
                    <p className="text-sm">Try searching for common Indian dishes like "dal", "rice", or "curry"</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Food Details & Logging */}
          {selectedFood && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{selectedFood.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Quantity</label>
                    <Input
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      min="0.1"
                      step="0.1"
                      className="mt-1"
                      data-testid="input-food-quantity"
                    />
                    <p className="text-xs text-gray-500 mt-1">Per {selectedFood.servingSize}</p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Meal Type</label>
                    <Select value={mealType} onValueChange={setMealType}>
                      <SelectTrigger className="mt-1" data-testid="select-meal-type">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="breakfast">Breakfast</SelectItem>
                        <SelectItem value="lunch">Lunch</SelectItem>
                        <SelectItem value="dinner">Dinner</SelectItem>
                        <SelectItem value="snack">Snack</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <p className="text-lg font-bold text-gray-800">
                      {Math.round(selectedFood.calories * parseFloat(quantity || "1"))}
                    </p>
                    <p className="text-xs text-gray-600">Calories</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-blue-600">
                      {Math.round(selectedFood.carbs * parseFloat(quantity || "1"))}g
                    </p>
                    <p className="text-xs text-gray-600">Carbs</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-green-600">
                      {Math.round(selectedFood.protein * parseFloat(quantity || "1"))}g
                    </p>
                    <p className="text-xs text-gray-600">Protein</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-yellow-600">
                      {Math.round(selectedFood.fat * parseFloat(quantity || "1"))}g
                    </p>
                    <p className="text-xs text-gray-600">Fat</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-bold text-purple-600">
                      {Math.round(selectedFood.fiber * parseFloat(quantity || "1"))}g
                    </p>
                    <p className="text-xs text-gray-600">Fiber</p>
                  </div>
                </div>

                <Button 
                  onClick={handleLogFood}
                  disabled={logFoodMutation.isPending || !quantity || parseFloat(quantity) <= 0}
                  className="w-full"
                  data-testid="button-log-food-confirm"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Log Food
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
