import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Utensils, 
  BarChart3, 
  Droplets, 
  Brain, 
  Trophy, 
  Target, 
  Heart 
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Food Logging", href: "/food-logging", icon: Utensils },
  { name: "Nutrition Analysis", href: "/nutrition-analysis", icon: BarChart3 },
  { name: "Water Intake", href: "/water-intake", icon: Droplets },
  { name: "Meditation", href: "/meditation", icon: Brain },
  { name: "75-Day Challenge", href: "/challenge", icon: Trophy },
  { name: "Goals", href: "/goals", icon: Target },
  { name: "Health Metrics", href: "/health-metrics", icon: Heart },
];

export function Sidebar() {
  const [location, navigate] = useLocation();

  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out">
      <div className="flex items-center justify-center h-16 bg-primary">
        <h1 className="text-white text-xl font-bold">NutriTrack</h1>
      </div>
      
      <nav className="mt-8">
        <div className="px-4 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <button
                key={item.name}
                onClick={() => navigate(item.href)}
                className={cn(
                  "flex items-center w-full px-4 py-3 text-left rounded-lg transition-colors",
                  isActive
                    ? "text-gray-700 bg-primary/10 border-r-4 border-primary"
                    : "text-gray-600 hover:bg-gray-100"
                )}
                data-testid={`nav-${item.href.replace('/', '') || 'home'}`}
              >
                <Icon className="w-5 h-5 mr-3" />
                {item.name}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
