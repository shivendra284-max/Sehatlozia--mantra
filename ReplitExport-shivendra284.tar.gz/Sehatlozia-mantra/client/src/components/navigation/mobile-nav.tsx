import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Utensils, 
  Droplets, 
  Brain, 
  Trophy,
  Menu,
  X 
} from "lucide-react";

const bottomNav = [
  { name: "Home", href: "/", icon: Home },
  { name: "Food", href: "/food-logging", icon: Utensils },
  { name: "Water", href: "/water-intake", icon: Droplets },
  { name: "Meditate", href: "/meditation", icon: Brain },
  { name: "Challenge", href: "/challenge", icon: Trophy },
];

const allNavigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Food Logging", href: "/food-logging", icon: Utensils },
  { name: "Nutrition Analysis", href: "/nutrition-analysis", icon: null },
  { name: "Water Intake", href: "/water-intake", icon: Droplets },
  { name: "Meditation", href: "/meditation", icon: Brain },
  { name: "75-Day Challenge", href: "/challenge", icon: Trophy },
  { name: "Goals", href: "/goals", icon: null },
  { name: "Health Metrics", href: "/health-metrics", icon: null },
];

export function MobileNav() {
  const [location, navigate] = useLocation();

  return (
    <>
      {/* Mobile Sidebar */}
      <div 
        id="mobile-sidebar"
        className="lg:hidden fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform -translate-x-full transition-transform duration-300 ease-in-out"
      >
        <div className="flex items-center justify-between h-16 px-4 bg-primary">
          <h1 className="text-white text-xl font-bold">NutriTrack</h1>
          <button 
            className="text-white"
            onClick={() => {
              const sidebar = document.getElementById('mobile-sidebar');
              if (sidebar) {
                sidebar.classList.add('-translate-x-full');
              }
            }}
            data-testid="button-close-sidebar"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <nav className="mt-8">
          <div className="px-4 space-y-2">
            {allNavigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;
              
              return (
                <button
                  key={item.name}
                  onClick={() => {
                    navigate(item.href);
                    const sidebar = document.getElementById('mobile-sidebar');
                    if (sidebar) {
                      sidebar.classList.add('-translate-x-full');
                    }
                  }}
                  className={cn(
                    "flex items-center w-full px-4 py-3 text-left rounded-lg transition-colors",
                    isActive
                      ? "text-gray-700 bg-primary/10 border-r-4 border-primary"
                      : "text-gray-600 hover:bg-gray-100"
                  )}
                  data-testid={`mobile-nav-${item.href.replace('/', '') || 'home'}`}
                >
                  {Icon && <Icon className="w-5 h-5 mr-3" />}
                  {!Icon && <div className="w-5 h-5 mr-3" />}
                  {item.name}
                </button>
              );
            })}
          </div>
        </nav>
      </div>

      {/* Bottom Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40">
        <div className="grid grid-cols-5 gap-1">
          {bottomNav.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <button
                key={item.name}
                onClick={() => navigate(item.href)}
                className={cn(
                  "flex flex-col items-center py-2 px-1 transition-colors",
                  isActive ? "text-primary" : "text-gray-600"
                )}
                data-testid={`bottom-nav-${item.href.replace('/', '') || 'home'}`}
              >
                <Icon className="w-5 h-5 mb-1" />
                <span className="text-xs">{item.name}</span>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
}
