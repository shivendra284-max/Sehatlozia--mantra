import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Droplets, Plus } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function WaterTracker() {
  const [customAmount, setCustomAmount] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const today = format(new Date(), 'yyyy-MM-dd');

  const { data: waterData } = useQuery({
    queryKey: ['/api/water-intake', today],
    queryFn: async () => {
      const res = await fetch(`/api/water-intake/${today}`);
      return res.json();
    }
  });

  const addWaterMutation = useMutation({
    mutationFn: async (amount: number) => {
      await apiRequest('POST', '/api/water-intake', {
        amount,
        date: today
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/water-intake'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Water logged successfully!",
        description: "Keep up the great hydration.",
      });
    }
  });

  const handleAddGlass = () => {
    addWaterMutation.mutate(250); // Standard glass is 250ml
  };

  const handleCustomAmount = () => {
    const amount = parseInt(customAmount);
    if (amount > 0) {
      addWaterMutation.mutate(amount);
      setCustomAmount("");
      setIsDialogOpen(false);
    }
  };

  const total = waterData?.total || 0;
  const goal = 2000; // 8 glasses of 250ml
  const glassesCount = Math.floor(total / 250);
  const progress = Math.min((total / goal) * 100, 100);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Water Intake</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-6">
          <div className="relative w-32 h-32 mx-auto mb-4">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
              <path 
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#E5E7EB"
                strokeWidth="3"
              />
              <path 
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#3B82F6"
                strokeWidth="3"
                strokeDasharray={`${progress}, 100`}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800">{(total / 250).toFixed(1)}</div>
                <div className="text-xs text-gray-500">of 8 glasses</div>
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-600">{Math.round(progress)}% of daily goal completed</p>
        </div>
        
        <div className="grid grid-cols-4 gap-2 mb-4">
          {Array(8).fill(0).map((_, index) => (
            <button
              key={index}
              onClick={handleAddGlass}
              className={`aspect-square rounded-lg flex items-center justify-center transition-all duration-200 water-glass ${
                index < glassesCount 
                  ? 'bg-blue-500 text-white hover:bg-blue-600' 
                  : index === glassesCount && total % 250 > 0
                  ? 'bg-blue-100 text-blue-300 hover:bg-blue-200'
                  : 'bg-gray-100 text-gray-300 hover:bg-gray-200'
              }`}
              disabled={addWaterMutation.isPending}
              data-testid={`button-water-glass-${index}`}
            >
              <Droplets className="w-4 h-4" />
            </button>
          ))}
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              className="w-full border-blue-200 text-blue-600 hover:bg-blue-50"
              data-testid="button-custom-water"
            >
              <Plus className="w-4 h-4 mr-2" />
              Custom Amount
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Custom Water Amount</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Amount (ml)</label>
                <Input
                  type="number"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  placeholder="e.g., 500"
                  className="mt-1"
                  data-testid="input-custom-water-amount"
                />
              </div>
              <Button 
                onClick={handleCustomAmount}
                disabled={!customAmount || addWaterMutation.isPending}
                className="w-full"
                data-testid="button-add-custom-water"
              >
                Add Water
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
