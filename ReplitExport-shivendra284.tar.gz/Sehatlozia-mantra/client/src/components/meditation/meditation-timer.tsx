import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Play, Pause, Square, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MeditationTimerProps {
  isOpen: boolean;
  onClose: () => void;
  duration: number;
}

export function MeditationTimer({ isOpen, onClose, duration }: MeditationTimerProps) {
  const [timeLeft, setTimeLeft] = useState(duration * 60); // Convert to seconds
  const [isRunning, setIsRunning] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const today = format(new Date(), 'yyyy-MM-dd');

  const saveMeditationMutation = useMutation({
    mutationFn: async (sessionData: { duration: number; notes?: string }) => {
      await apiRequest('POST', '/api/meditation', {
        duration: sessionData.duration,
        sessionType: 'guided',
        notes: sessionData.notes,
        date: today
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/meditation'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Meditation session saved!",
        description: "Great job on your mindfulness practice.",
      });
      onClose();
      resetTimer();
    }
  });

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => {
          if (time <= 1) {
            setIsRunning(false);
            setIsCompleted(true);
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  useEffect(() => {
    if (isOpen) {
      setTimeLeft(duration * 60);
      setIsRunning(false);
      setIsCompleted(false);
      setNotes("");
    }
  }, [isOpen, duration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleStop = () => {
    setIsRunning(false);
    const completedMinutes = Math.ceil((duration * 60 - timeLeft) / 60);
    if (completedMinutes > 0) {
      saveMeditationMutation.mutate({ duration: completedMinutes, notes });
    } else {
      onClose();
      resetTimer();
    }
  };

  const handleComplete = () => {
    saveMeditationMutation.mutate({ duration, notes });
  };

  const resetTimer = () => {
    setTimeLeft(duration * 60);
    setIsRunning(false);
    setIsCompleted(false);
    setNotes("");
  };

  const progress = ((duration * 60 - timeLeft) / (duration * 60)) * 100;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isCompleted ? "Session Complete!" : `${duration} Minute Meditation`}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {isCompleted ? (
            <div className="text-center">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-800">Wonderful!</p>
              <p className="text-sm text-gray-600">You completed your {duration}-minute meditation.</p>
            </div>
          ) : (
            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-4">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 36 36">
                  <path 
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#E5E7EB"
                    strokeWidth="3"
                  />
                  <path 
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#8B5CF6"
                    strokeWidth="3"
                    strokeDasharray={`${progress}, 100`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-2xl font-bold text-gray-800">
                    {formatTime(timeLeft)}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center space-x-3">
                {!isRunning ? (
                  <Button 
                    onClick={handleStart}
                    className="bg-purple-500 hover:bg-purple-600"
                    data-testid="button-start-meditation"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start
                  </Button>
                ) : (
                  <Button 
                    onClick={handlePause}
                    variant="outline"
                    data-testid="button-pause-meditation"
                  >
                    <Pause className="w-4 h-4 mr-2" />
                    Pause
                  </Button>
                )}
                
                <Button 
                  onClick={handleStop}
                  variant="outline"
                  data-testid="button-stop-meditation"
                >
                  <Square className="w-4 h-4 mr-2" />
                  Stop
                </Button>
              </div>
            </div>
          )}

          {isCompleted && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Session Notes (Optional)</label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="How did you feel during this session?"
                  className="mt-1"
                  data-testid="textarea-meditation-notes"
                />
              </div>
              
              <Button 
                onClick={handleComplete}
                disabled={saveMeditationMutation.isPending}
                className="w-full bg-purple-500 hover:bg-purple-600"
                data-testid="button-save-meditation"
              >
                Save Session
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
