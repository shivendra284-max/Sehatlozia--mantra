import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/navigation/sidebar";
import { MobileNav } from "@/components/navigation/mobile-nav";
import Dashboard from "@/pages/dashboard";
import FoodLogging from "@/pages/food-logging";
import NutritionAnalysis from "@/pages/nutrition-analysis";
import WaterIntake from "@/pages/water-intake";
import Meditation from "@/pages/meditation";
import Challenge from "@/pages/challenge";
import Goals from "@/pages/goals";
import HealthMetrics from "@/pages/health-metrics";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/food-logging" component={FoodLogging} />
      <Route path="/nutrition-analysis" component={NutritionAnalysis} />
      <Route path="/water-intake" component={WaterIntake} />
      <Route path="/meditation" component={Meditation} />
      <Route path="/challenge" component={Challenge} />
      <Route path="/goals" component={Goals} />
      <Route path="/health-metrics" component={HealthMetrics} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-gray-50">
          <Sidebar />
          <MobileNav />
          
          {/* Mobile Header */}
          <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-white shadow-sm">
            <div className="flex items-center justify-between p-4">
              <button 
                className="text-gray-600"
                onClick={() => {
                  const sidebar = document.getElementById('mobile-sidebar');
                  if (sidebar) {
                    sidebar.classList.toggle('-translate-x-full');
                  }
                }}
                data-testid="button-toggle-sidebar"
              >
                <i className="fas fa-bars text-xl"></i>
              </button>
              <h1 className="text-lg font-semibold text-gray-800">NutriTrack</h1>
              <button className="text-gray-600" data-testid="button-notifications">
                <i className="fas fa-bell text-xl"></i>
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:ml-64 pt-16 lg:pt-0 pb-16 lg:pb-0 min-h-screen">
            <Router />
          </div>
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
