import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import type { DailyNutrition, NutritionGoals } from "@shared/schema";

export function useNutrition(date?: string) {
  const targetDate = date || format(new Date(), 'yyyy-MM-dd');

  const { data: dailyNutrition, isLoading: isNutritionLoading } = useQuery<DailyNutrition>({
    queryKey: ['/api/nutrition', targetDate],
    queryFn: async () => {
      const res = await fetch(`/api/nutrition/${targetDate}`);
      return res.json();
    }
  });

  const { data: nutritionGoals, isLoading: isGoalsLoading } = useQuery<NutritionGoals>({
    queryKey: ['/api/nutrition-goals'],
    queryFn: async () => {
      const res = await fetch('/api/nutrition-goals');
      return res.json();
    }
  });

  const calculateProgress = (current: number, target: number) => {
    return Math.min((current / target) * 100, 100);
  };

  const getProgressStatus = (progress: number) => {
    if (progress >= 90) return { status: 'excellent', color: 'text-green-600', bgColor: 'bg-green-50' };
    if (progress >= 70) return { status: 'good', color: 'text-blue-600', bgColor: 'bg-blue-50' };
    if (progress >= 50) return { status: 'fair', color: 'text-yellow-600', bgColor: 'bg-yellow-50' };
    return { status: 'low', color: 'text-red-600', bgColor: 'bg-red-50' };
  };

  const getNutritionInsights = () => {
    if (!dailyNutrition || !nutritionGoals) return [];

    const insights = [];

    // Protein intake check
    if (dailyNutrition.protein >= nutritionGoals.protein * 0.9) {
      insights.push({
        type: 'positive',
        message: 'Great protein intake today!',
        icon: '💪',
        color: 'bg-green-50 text-green-700'
      });
    } else if (dailyNutrition.protein < nutritionGoals.protein * 0.5) {
      insights.push({
        type: 'warning',
        message: 'Consider adding more protein to your meals',
        icon: '🥚',
        color: 'bg-yellow-50 text-yellow-700'
      });
    }

    // Fiber intake check
    if (dailyNutrition.fiber >= nutritionGoals.fiber * 0.8) {
      insights.push({
        type: 'positive',
        message: 'Good fiber intake for digestive health',
        icon: '🌾',
        color: 'bg-blue-50 text-blue-700'
      });
    }

    // Calorie check
    if (dailyNutrition.calories < nutritionGoals.calories * 0.7) {
      insights.push({
        type: 'warning',
        message: 'Consider eating more to meet calorie goals',
        icon: '🍽️',
        color: 'bg-yellow-50 text-yellow-700'
      });
    } else if (dailyNutrition.calories > nutritionGoals.calories * 1.2) {
      insights.push({
        type: 'caution',
        message: 'Calorie intake is higher than your goal',
        icon: '⚖️',
        color: 'bg-orange-50 text-orange-700'
      });
    }

    // Sodium check
    if (dailyNutrition.sodium > 2000) {
      insights.push({
        type: 'caution',
        message: 'High sodium intake - consider reducing salt',
        icon: '🧂',
        color: 'bg-red-50 text-red-700'
      });
    }

    // Sugar check
    if (dailyNutrition.sugar > 50) {
      insights.push({
        type: 'caution',
        message: 'Sugar intake is quite high today',
        icon: '🍬',
        color: 'bg-red-50 text-red-700'
      });
    }

    return insights;
  };

  const getMacroBreakdown = () => {
    if (!dailyNutrition) return null;

    const totalCalories = dailyNutrition.calories;
    const carbCalories = dailyNutrition.carbs * 4;
    const proteinCalories = dailyNutrition.protein * 4;
    const fatCalories = dailyNutrition.fat * 9;

    return {
      carbs: {
        grams: dailyNutrition.carbs,
        calories: carbCalories,
        percentage: totalCalories > 0 ? Math.round((carbCalories / totalCalories) * 100) : 0
      },
      protein: {
        grams: dailyNutrition.protein,
        calories: proteinCalories,
        percentage: totalCalories > 0 ? Math.round((proteinCalories / totalCalories) * 100) : 0
      },
      fat: {
        grams: dailyNutrition.fat,
        calories: fatCalories,
        percentage: totalCalories > 0 ? Math.round((fatCalories / totalCalories) * 100) : 0
      }
    };
  };

  const getNutrientProgress = () => {
    if (!dailyNutrition || !nutritionGoals) return [];

    return [
      {
        name: 'Calories',
        current: Math.round(dailyNutrition.calories),
        target: nutritionGoals.calories,
        unit: '',
        progress: calculateProgress(dailyNutrition.calories, nutritionGoals.calories),
        color: 'bg-primary'
      },
      {
        name: 'Carbohydrates',
        current: Math.round(dailyNutrition.carbs),
        target: Math.round(nutritionGoals.carbs),
        unit: 'g',
        progress: calculateProgress(dailyNutrition.carbs, nutritionGoals.carbs),
        color: 'bg-blue-500'
      },
      {
        name: 'Protein',
        current: Math.round(dailyNutrition.protein),
        target: Math.round(nutritionGoals.protein),
        unit: 'g',
        progress: calculateProgress(dailyNutrition.protein, nutritionGoals.protein),
        color: 'bg-green-500'
      },
      {
        name: 'Fat',
        current: Math.round(dailyNutrition.fat),
        target: Math.round(nutritionGoals.fat),
        unit: 'g',
        progress: calculateProgress(dailyNutrition.fat, nutritionGoals.fat),
        color: 'bg-yellow-500'
      },
      {
        name: 'Fiber',
        current: Math.round(dailyNutrition.fiber),
        target: Math.round(nutritionGoals.fiber),
        unit: 'g',
        progress: calculateProgress(dailyNutrition.fiber, nutritionGoals.fiber),
        color: 'bg-purple-500'
      }
    ];
  };

  const isLoading = isNutritionLoading || isGoalsLoading;

  return {
    dailyNutrition,
    nutritionGoals,
    isLoading,
    calculateProgress,
    getProgressStatus,
    getNutritionInsights,
    getMacroBreakdown,
    getNutrientProgress,
  };
}

export default useNutrition;
