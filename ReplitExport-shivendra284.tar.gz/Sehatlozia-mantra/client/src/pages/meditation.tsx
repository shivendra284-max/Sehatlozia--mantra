import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { MeditationTimer } from "@/components/meditation/meditation-timer";
import { Brain, Play, Clock, Calendar, Target, TrendingUp } from "lucide-react";
import { format, subDays } from "date-fns";

const Meditation = () => {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [isTimerOpen, setIsTimerOpen] = useState(false);
  const [selectedDuration, setSelectedDuration] = useState(5);

  const { data: todaysSessions, isLoading } = useQuery({
    queryKey: ['/api/meditation', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/meditation?date=${selectedDate}`);
      return res.json();
    }
  });

  const { data: todaysTotal } = useQuery({
    queryKey: ['/api/meditation/total', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/meditation/total/${selectedDate}`);
      return res.json();
    }
  });

  const { data: streak } = useQuery({
    queryKey: ['/api/meditation/streak'],
    queryFn: async () => {
      const res = await fetch('/api/meditation/streak');
      return res.json();
    }
  });

  const { data: weeklyData } = useQuery({
    queryKey: ['/api/meditation/weekly', selectedDate],
    queryFn: async () => {
      const days = [];
      for (let i = 6; i >= 0; i--) {
        const date = format(subDays(new Date(selectedDate), i), 'yyyy-MM-dd');
        const res = await fetch(`/api/meditation/total/${date}`);
        const data = await res.json();
        days.push({
          date,
          dayName: format(subDays(new Date(selectedDate), i), 'EEE'),
          total: data.total || 0
        });
      }
      return days;
    }
  });

  const handleStartMeditation = (duration: number) => {
    setSelectedDuration(duration);
    setIsTimerOpen(true);
  };

  const totalMinutes = todaysTotal?.total || 0;
  const dailyGoal = 20; // minutes
  const progress = Math.min((totalMinutes / dailyGoal) * 100, 100);
  const currentStreak = streak?.streak || 0;

  const sessionTypes = [
    { duration: 5, title: "Quick Mindfulness", description: "Perfect for beginners", color: "bg-green-100 text-green-700", icon: "🌱" },
    { duration: 10, title: "Focus Session", description: "Enhance concentration", color: "bg-blue-100 text-blue-700", icon: "🎯" },
    { duration: 15, title: "Deep Relaxation", description: "Stress relief & calm", color: "bg-purple-100 text-purple-700", icon: "🧘‍♀️" },
    { duration: 20, title: "Complete Practice", description: "Full mindfulness experience", color: "bg-indigo-100 text-indigo-700", icon: "✨" },
    { duration: 30, title: "Extended Session", description: "Deep meditation", color: "bg-pink-100 text-pink-700", icon: "🌸" },
  ];

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="mb-4 lg:mb-0">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800">Meditation & Mindfulness</h2>
            <p className="text-gray-600 mt-1">Find your inner peace and build a mindful habit</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <p className="text-sm text-gray-600">Today's Progress</p>
              <p className="text-lg font-bold text-purple-600">{totalMinutes} minutes</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Brain className="w-5 h-5 text-purple-500" />
                <span>Today's Meditation</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <p className="text-3xl font-bold text-purple-600">{totalMinutes}</p>
                  <p className="text-sm text-gray-600">Minutes Today</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-3xl font-bold text-green-600">{currentStreak}</p>
                  <p className="text-sm text-gray-600">Day Streak</p>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-3xl font-bold text-blue-600">{todaysSessions?.length || 0}</p>
                  <p className="text-sm text-gray-600">Sessions</p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span>Daily Goal Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-3" />
                <p className="text-center text-sm text-gray-600 mt-2">
                  {progress >= 100 ? "🎉 Daily goal achieved!" : `${dailyGoal - totalMinutes} minutes to reach your daily goal`}
                </p>
              </div>

              {/* Streak Visualization */}
              <div className="text-center">
                <p className="text-sm font-medium text-gray-600 mb-3">Meditation Streak</p>
                <div className="flex justify-center space-x-2 mb-2">
                  {Array(7).fill(0).map((_, index) => {
                    const isCompleted = index < currentStreak;
                    return (
                      <div 
                        key={index} 
                        className={`w-8 h-8 rounded-full flex items-center justify-center meditation-streak-dot ${
                          isCompleted 
                            ? 'bg-purple-500 text-white' 
                            : 'bg-gray-200 text-gray-400'
                        }`}
                      >
                        {isCompleted ? '✓' : index + 1}
                      </div>
                    );
                  })}
                </div>
                <p className="text-xs text-gray-500">
                  {currentStreak > 0 ? `${currentStreak} consecutive days` : 'Start your streak today!'}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Session Types */}
          <Card>
            <CardHeader>
              <CardTitle>Choose Your Practice</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sessionTypes.map((session) => (
                  <Card key={session.duration} className="cursor-pointer hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{session.icon}</span>
                          <div>
                            <h3 className="font-medium text-gray-800">{session.title}</h3>
                            <p className="text-sm text-gray-600">{session.description}</p>
                          </div>
                        </div>
                        <Badge className={session.color}>
                          {session.duration} min
                        </Badge>
                      </div>
                      <Button 
                        onClick={() => handleStartMeditation(session.duration)}
                        className="w-full bg-purple-500 hover:bg-purple-600"
                        data-testid={`button-start-${session.duration}min`}
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Start Session
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Sessions */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              {todaysSessions && todaysSessions.length > 0 ? (
                <div className="space-y-3">
                  {todaysSessions.map((session: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                          <Brain className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-800">{session.duration} minute session</p>
                          <p className="text-sm text-gray-600 capitalize">{session.sessionType}</p>
                          {session.notes && (
                            <p className="text-xs text-gray-500 mt-1">{session.notes}</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">
                          {format(new Date(session.completedAt), 'h:mm a')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Brain className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>No meditation sessions today</p>
                  <p className="text-sm">Start your mindfulness journey above</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Analytics */}
        <div className="space-y-6">
          {/* Weekly Progress */}
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-purple-500" />
                <CardTitle>Weekly Progress</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {weeklyData?.map((day: any) => (
                  <div key={day.date} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-600">{day.dayName}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-20 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-purple-500 h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${Math.min((day.total / 20) * 100, 100)}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-500 min-w-[35px]">{day.total}m</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Meditation Benefits */}
          <Card>
            <CardHeader>
              <CardTitle>✨ Benefits You're Gaining</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3 text-sm">
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="font-medium text-green-800">Stress Reduction</p>
                  <p className="text-green-600">Lower cortisol levels and anxiety</p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="font-medium text-blue-800">Better Focus</p>
                  <p className="text-blue-600">Improved concentration and attention</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <p className="font-medium text-purple-800">Better Sleep</p>
                  <p className="text-purple-600">Enhanced sleep quality and relaxation</p>
                </div>
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <p className="font-medium text-yellow-800">Emotional Balance</p>
                  <p className="text-yellow-600">Greater emotional regulation</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Meditation Goals */}
          <Card>
            <CardHeader>
              <CardTitle>Goals & Achievements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-800">Daily Goal</p>
                    <p className="text-xs text-gray-600">20 minutes per day</p>
                  </div>
                  <div className="text-right">
                    <div className="w-12 bg-gray-200 rounded-full h-2">
                      <div className="bg-purple-500 h-2 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                    <span className="text-xs text-gray-500">{Math.round(progress)}%</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-gray-800">Weekly Goal</p>
                    <p className="text-xs text-gray-600">5 days of meditation</p>
                  </div>
                  <div className="text-right">
                    <div className="w-12 bg-gray-200 rounded-full h-2">
                      <div className="bg-purple-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                    </div>
                    <span className="text-xs text-gray-500">3/5</span>
                  </div>
                </div>
              </div>

              {/* Achievements */}
              <div className="pt-2 border-t">
                <p className="text-sm font-medium text-gray-800 mb-2">Recent Achievements</p>
                {currentStreak >= 7 && (
                  <div className="flex items-center p-2 bg-yellow-50 rounded-lg mb-2">
                    <span className="text-lg mr-2">🔥</span>
                    <div>
                      <p className="text-sm font-medium text-yellow-800">Week Warrior</p>
                      <p className="text-xs text-yellow-600">7-day meditation streak</p>
                    </div>
                  </div>
                )}
                {totalMinutes >= 60 && (
                  <div className="flex items-center p-2 bg-blue-50 rounded-lg">
                    <span className="text-lg mr-2">⏰</span>
                    <div>
                      <p className="text-sm font-medium text-blue-800">Time Master</p>
                      <p className="text-xs text-blue-600">1 hour in a single day</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Meditation Timer Modal */}
      <MeditationTimer 
        isOpen={isTimerOpen} 
        onClose={() => setIsTimerOpen(false)} 
        duration={selectedDuration}
      />
    </div>
  );
};

export default Meditation;
