import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Droplets, Plus, Target, TrendingUp, Calendar } from "lucide-react";
import { format, subDays } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Line } from 'react-chartjs-2';

const WaterIntake = () => {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [customAmount, setCustomAmount] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [dailyGoal, setDailyGoal] = useState(2000);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: waterData, isLoading } = useQuery({
    queryKey: ['/api/water-intake', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/water-intake/${selectedDate}`);
      return res.json();
    }
  });

  const { data: weeklyData } = useQuery({
    queryKey: ['/api/water-intake/weekly', selectedDate],
    queryFn: async () => {
      const days = [];
      for (let i = 6; i >= 0; i--) {
        const date = format(subDays(new Date(selectedDate), i), 'yyyy-MM-dd');
        const res = await fetch(`/api/water-intake/${date}`);
        const data = await res.json();
        days.push({
          date,
          dayName: format(subDays(new Date(selectedDate), i), 'EEE'),
          total: data.total || 0
        });
      }
      return days;
    }
  });

  const addWaterMutation = useMutation({
    mutationFn: async (amount: number) => {
      await apiRequest('POST', '/api/water-intake', {
        amount,
        date: selectedDate
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/water-intake'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Water logged successfully!",
        description: "Keep up the great hydration.",
      });
    }
  });

  const handleAddWater = (amount: number) => {
    addWaterMutation.mutate(amount);
  };

  const handleCustomAmount = () => {
    const amount = parseInt(customAmount);
    if (amount > 0) {
      addWaterMutation.mutate(amount);
      setCustomAmount("");
      setIsDialogOpen(false);
    }
  };

  const total = waterData?.total || 0;
  const glassesCount = Math.floor(total / 250);
  const progress = Math.min((total / dailyGoal) * 100, 100);

  const weeklyChartData = {
    labels: weeklyData?.map(d => d.dayName) || [],
    datasets: [
      {
        label: 'Water Intake (ml)',
        data: weeklyData?.map(d => d.total) || [],
        borderColor: 'hsl(216.8421 87.2340% 64.5098%)',
        backgroundColor: 'hsl(216.8421 87.2340% 64.5098% / 0.1)',
        fill: true,
        tension: 0.3,
      }
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Water (ml)',
        },
        grid: {
          color: 'hsl(0 0% 90%)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const quickAmounts = [
    { label: '1 Glass', amount: 250, icon: '🥛' },
    { label: '1 Bottle', amount: 500, icon: '🍼' },
    { label: '1 Liter', amount: 1000, icon: '💧' },
    { label: 'Tea Cup', amount: 150, icon: '☕' },
  ];

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="mb-4 lg:mb-0">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800">Water Intake Tracker</h2>
            <p className="text-gray-600 mt-1">Stay hydrated and track your daily water consumption</p>
          </div>
          <div className="flex items-center space-x-3">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
              data-testid="input-date-picker"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Main Tracker */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main Water Tracker */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Today's Water Intake</CardTitle>
                <div className="flex items-center space-x-2">
                  <Target className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-600">Goal: {dailyGoal}ml</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-8">
                <div className="relative w-40 h-40 mx-auto mb-6">
                  <svg className="w-40 h-40 transform -rotate-90" viewBox="0 0 36 36">
                    <path 
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#E5E7EB"
                      strokeWidth="2"
                    />
                    <path 
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#3B82F6"
                      strokeWidth="2"
                      strokeDasharray={`${progress}, 100`}
                      className="transition-all duration-500"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-gray-800">{total}ml</div>
                      <div className="text-sm text-gray-500">of {dailyGoal}ml</div>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">{(total / 250).toFixed(1)}</p>
                    <p className="text-sm text-gray-600">Glasses</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">{Math.round(progress)}%</p>
                    <p className="text-sm text-gray-600">Goal Achieved</p>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <Progress value={progress} className="h-3 mb-2" />
                <p className="text-center text-sm text-gray-600">
                  {progress >= 100 ? "🎉 Daily goal achieved!" : `${dailyGoal - total}ml remaining to reach your goal`}
                </p>
              </div>

              {/* Glass Visualization */}
              <div className="grid grid-cols-8 gap-2 mb-6">
                {Array(8).fill(0).map((_, index) => (
                  <div
                    key={index}
                    className={`aspect-square rounded-lg flex items-center justify-center transition-all duration-200 water-glass ${
                      index < glassesCount 
                        ? 'bg-blue-500 text-white' 
                        : index === glassesCount && total % 250 > 0
                        ? 'bg-blue-200 text-blue-600'
                        : 'bg-gray-100 text-gray-300'
                    }`}
                  >
                    <Droplets className="w-4 h-4" />
                  </div>
                ))}
              </div>

              {/* Quick Add Buttons */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {quickAmounts.map((item) => (
                  <Button
                    key={item.amount}
                    variant="outline"
                    onClick={() => handleAddWater(item.amount)}
                    disabled={addWaterMutation.isPending}
                    className="flex flex-col items-center p-4 h-auto border-blue-200 hover:bg-blue-50"
                    data-testid={`button-add-${item.amount}ml`}
                  >
                    <span className="text-2xl mb-2">{item.icon}</span>
                    <span className="text-sm font-medium">{item.label}</span>
                    <span className="text-xs text-gray-500">{item.amount}ml</span>
                  </Button>
                ))}
              </div>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    className="w-full mt-4 border-blue-200 text-blue-600 hover:bg-blue-50"
                    data-testid="button-custom-amount"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Custom Amount
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Custom Water Amount</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Amount (ml)</label>
                      <Input
                        type="number"
                        value={customAmount}
                        onChange={(e) => setCustomAmount(e.target.value)}
                        placeholder="e.g., 350"
                        className="mt-1"
                        data-testid="input-custom-amount"
                      />
                    </div>
                    <Button 
                      onClick={handleCustomAmount}
                      disabled={!customAmount || addWaterMutation.isPending}
                      className="w-full"
                      data-testid="button-add-custom-amount"
                    >
                      Add Water
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>

          {/* Water History */}
          <Card>
            <CardHeader>
              <CardTitle>Today's Water Log</CardTitle>
            </CardHeader>
            <CardContent>
              {waterData?.intakes && waterData.intakes.length > 0 ? (
                <div className="space-y-3">
                  {waterData.intakes.map((intake: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Droplets className="w-5 h-5 text-blue-500" />
                        <span className="font-medium">{intake.amount}ml</span>
                      </div>
                      <span className="text-sm text-gray-600">
                        {format(new Date(intake.loggedAt), 'h:mm a')}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Droplets className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>No water logged today</p>
                  <p className="text-sm">Start tracking your hydration above</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Analytics */}
        <div className="space-y-6">
          {/* Weekly Trend */}
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-blue-500" />
                <CardTitle>7-Day Trend</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                {weeklyData ? (
                  <Line data={weeklyChartData} options={chartOptions} />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Hydration Tips */}
          <Card>
            <CardHeader>
              <CardTitle>💡 Hydration Tips</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3 text-sm">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="font-medium text-blue-800">Start your day right</p>
                  <p className="text-blue-600">Drink a glass of water when you wake up</p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="font-medium text-green-800">Before meals</p>
                  <p className="text-green-600">Have water 30 minutes before eating</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <p className="font-medium text-purple-800">Exercise hydration</p>
                  <p className="text-purple-600">Drink extra water during workouts</p>
                </div>
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <p className="font-medium text-yellow-800">Listen to your body</p>
                  <p className="text-yellow-600">Thirst is a late indicator of dehydration</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Goal Setting */}
          <Card>
            <CardHeader>
              <CardTitle>Daily Goal</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-blue-600">{dailyGoal}ml</p>
                <p className="text-sm text-gray-600">Current daily goal</p>
              </div>
              <div className="space-y-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={() => setDailyGoal(1500)}
                >
                  🥤 Light Activity (1.5L)
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={() => setDailyGoal(2000)}
                >
                  💧 Normal Activity (2L)
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={() => setDailyGoal(2500)}
                >
                  🏃 Active Lifestyle (2.5L)
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-start"
                  onClick={() => setDailyGoal(3000)}
                >
                  🏋️ High Activity (3L)
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default WaterIntake;
