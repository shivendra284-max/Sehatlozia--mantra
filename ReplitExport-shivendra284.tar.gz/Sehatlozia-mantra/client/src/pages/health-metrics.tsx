import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Heart, Scale, Activity, Moon, Thermometer, Plus, TrendingUp, Calendar } from "lucide-react";
import { format, subDays } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { Line } from 'react-chartjs-2';
import type { HealthMetrics } from "@shared/schema";

const healthMetricsSchema = z.object({
  weight: z.number().min(20).max(300).optional(),
  height: z.number().min(100).max(250).optional(),
  steps: z.number().min(0).max(100000).optional(),
  sleepHours: z.number().min(0).max(24).optional(),
  bloodPressureSystolic: z.number().min(70).max(250).optional(),
  bloodPressureDiastolic: z.number().min(40).max(150).optional(),
  heartRate: z.number().min(40).max(200).optional(),
});

type HealthMetricsFormData = z.infer<typeof healthMetricsSchema>;

const HealthMetricsPage = () => {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: todaysMetrics, isLoading } = useQuery<HealthMetrics[]>({
    queryKey: ['/api/health-metrics', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/health-metrics?date=${selectedDate}`);
      return res.json();
    }
  });

  const { data: latestMetrics } = useQuery<HealthMetrics>({
    queryKey: ['/api/health-metrics/latest'],
    queryFn: async () => {
      const res = await fetch('/api/health-metrics/latest');
      return res.json();
    }
  });

  const { data: weeklyData } = useQuery({
    queryKey: ['/api/health-metrics/weekly', selectedDate],
    queryFn: async () => {
      const days = [];
      for (let i = 6; i >= 0; i--) {
        const date = format(subDays(new Date(selectedDate), i), 'yyyy-MM-dd');
        const res = await fetch(`/api/health-metrics?date=${date}`);
        const data = await res.json();
        days.push({
          date,
          dayName: format(subDays(new Date(selectedDate), i), 'EEE'),
          metrics: data[0] || null
        });
      }
      return days;
    }
  });

  const form = useForm<HealthMetricsFormData>({
    resolver: zodResolver(healthMetricsSchema),
    defaultValues: {
      weight: undefined,
      height: undefined,
      steps: undefined,
      sleepHours: undefined,
      bloodPressureSystolic: undefined,
      bloodPressureDiastolic: undefined,
      heartRate: undefined,
    }
  });

  const addMetricsMutation = useMutation({
    mutationFn: async (data: HealthMetricsFormData) => {
      // Filter out undefined values
      const cleanData = Object.fromEntries(
        Object.entries(data).filter(([_, value]) => value !== undefined && value !== null)
      );
      
      await apiRequest('POST', '/api/health-metrics', {
        ...cleanData,
        date: selectedDate
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/health-metrics'] });
      toast({
        title: "Health metrics recorded!",
        description: "Your health data has been saved.",
      });
      setIsAddModalOpen(false);
      form.reset();
    }
  });

  const handleAddMetrics = (data: HealthMetricsFormData) => {
    addMetricsMutation.mutate(data);
  };

  const metrics = todaysMetrics?.[0];
  const latest = latestMetrics;

  const metricCards = [
    {
      title: "Weight",
      value: metrics?.weight || latest?.weight,
      unit: "kg",
      icon: Scale,
      color: "text-blue-600 bg-blue-50",
      target: "65 kg goal",
      change: latest?.weight && metrics?.weight ? (metrics.weight - latest.weight).toFixed(1) : null
    },
    {
      title: "Steps",
      value: metrics?.steps,
      unit: "steps",
      icon: Activity,
      color: "text-green-600 bg-green-50",
      target: "10,000 goal",
      change: null
    },
    {
      title: "Sleep",
      value: metrics?.sleepHours,
      unit: "hours",
      icon: Moon,
      color: "text-purple-600 bg-purple-50",
      target: "8 hours goal",
      change: null
    },
    {
      title: "Heart Rate",
      value: metrics?.heartRate,
      unit: "bpm",
      icon: Heart,
      color: "text-red-600 bg-red-50",
      target: "60-100 normal",
      change: null
    }
  ];

  const weightChartData = {
    labels: weeklyData?.map(d => d.dayName) || [],
    datasets: [
      {
        label: 'Weight (kg)',
        data: weeklyData?.map(d => d.metrics?.weight || null) || [],
        borderColor: 'hsl(216.8421 87.2340% 64.5098%)',
        backgroundColor: 'hsl(216.8421 87.2340% 64.5098% / 0.1)',
        tension: 0.3,
        spanGaps: true,
      }
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: false,
        title: {
          display: true,
          text: 'Weight (kg)',
        },
      },
      x: {
        grid: {
          display: false,
        },
      },
    },
  };

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="mb-4 lg:mb-0">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800">Health Metrics</h2>
            <p className="text-gray-600 mt-1">Track your vital health indicators and wellness data</p>
          </div>
          <div className="flex items-center space-x-3">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
              data-testid="input-date-picker"
            />
            <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary/90" data-testid="button-add-metrics">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Metrics
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Record Health Metrics</DialogTitle>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleAddMetrics)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="weight"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Weight (kg)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.1"
                                placeholder="65.5" 
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                                data-testid="input-weight"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="height"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Height (cm)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="170" 
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                                data-testid="input-height"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="steps"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Steps</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="8500" 
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                                data-testid="input-steps"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="sleepHours"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sleep (hours)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.5"
                                placeholder="7.5" 
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseFloat(e.target.value) : undefined)}
                                data-testid="input-sleep"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="bloodPressureSystolic"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>BP Systolic</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="120" 
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                                data-testid="input-bp-systolic"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="bloodPressureDiastolic"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>BP Diastolic</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="80" 
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                                data-testid="input-bp-diastolic"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="heartRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Heart Rate (bpm)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="72" 
                              {...field}
                              onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                              data-testid="input-heart-rate"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      disabled={addMetricsMutation.isPending}
                      className="w-full"
                      data-testid="button-save-metrics"
                    >
                      Save Metrics
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Metrics Cards */}
        <div className="lg:col-span-2 space-y-6">
          {/* Metrics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {metricCards.map((metric) => {
              const IconComponent = metric.icon;
              
              return (
                <Card key={metric.title} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${metric.color}`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      {metric.change && (
                        <Badge variant={parseFloat(metric.change) > 0 ? "destructive" : "default"} className="text-xs">
                          {parseFloat(metric.change) > 0 ? '+' : ''}{metric.change}
                        </Badge>
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                      <p className="text-2xl font-bold text-gray-800">
                        {metric.value ? `${metric.value}${metric.unit === 'steps' ? '' : ' ' + metric.unit}` : '-'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">{metric.target}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Detailed Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Detailed Health Data</CardTitle>
            </CardHeader>
            <CardContent>
              {metrics ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {metrics.bloodPressureSystolic && metrics.bloodPressureDiastolic && (
                      <div className="p-4 bg-red-50 rounded-lg">
                        <div className="flex items-center space-x-2 mb-2">
                          <Heart className="w-5 h-5 text-red-600" />
                          <h3 className="font-semibold text-red-800">Blood Pressure</h3>
                        </div>
                        <p className="text-lg font-bold text-red-600">
                          {metrics.bloodPressureSystolic}/{metrics.bloodPressureDiastolic} mmHg
                        </p>
                        <p className="text-sm text-red-700">
                          {metrics.bloodPressureSystolic < 120 && metrics.bloodPressureDiastolic < 80 
                            ? "Normal" 
                            : metrics.bloodPressureSystolic < 140 && metrics.bloodPressureDiastolic < 90
                            ? "Elevated"
                            : "High"}
                        </p>
                      </div>
                    )}

                    {metrics.weight && metrics.height && (
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <div className="flex items-center space-x-2 mb-2">
                          <Scale className="w-5 h-5 text-blue-600" />
                          <h3 className="font-semibold text-blue-800">BMI</h3>
                        </div>
                        <p className="text-lg font-bold text-blue-600">
                          {(metrics.weight / Math.pow(metrics.height / 100, 2)).toFixed(1)}
                        </p>
                        <p className="text-sm text-blue-700">
                          {(() => {
                            const bmi = metrics.weight / Math.pow(metrics.height / 100, 2);
                            if (bmi < 18.5) return "Underweight";
                            if (bmi < 25) return "Normal";
                            if (bmi < 30) return "Overweight";
                            return "Obese";
                          })()}
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    {metrics.steps && (
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <p className="font-medium text-gray-800">{metrics.steps.toLocaleString()}</p>
                        <p className="text-gray-600">Steps</p>
                      </div>
                    )}
                    {metrics.sleepHours && (
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <p className="font-medium text-gray-800">{metrics.sleepHours}h</p>
                        <p className="text-gray-600">Sleep</p>
                      </div>
                    )}
                    {metrics.heartRate && (
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <p className="font-medium text-gray-800">{metrics.heartRate}</p>
                        <p className="text-gray-600">BPM</p>
                      </div>
                    )}
                    {metrics.weight && (
                      <div className="text-center p-3 bg-gray-50 rounded-lg">
                        <p className="font-medium text-gray-800">{metrics.weight}kg</p>
                        <p className="text-gray-600">Weight</p>
                      </div>
                    )}
                  </div>

                  <div className="text-center text-sm text-gray-500">
                    Recorded on {format(new Date(metrics.recordedAt), 'MMMM d, yyyy')} at {format(new Date(metrics.recordedAt), 'h:mm a')}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Thermometer className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>No health metrics recorded for this date</p>
                  <p className="text-sm">Add your health data using the button above</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Charts & Trends */}
        <div className="space-y-6">
          {/* Weight Trend */}
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-blue-500" />
                <CardTitle>Weight Trend</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="h-48">
                {weeklyData ? (
                  <Line data={weightChartData} options={chartOptions} />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Health Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Health Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3 text-sm">
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="font-medium text-green-800">💚 Stay Active</p>
                  <p className="text-green-600">Aim for 150 minutes of moderate exercise weekly</p>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="font-medium text-blue-800">💧 Hydration</p>
                  <p className="text-blue-600">Drink 8-10 glasses of water daily</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <p className="font-medium text-purple-800">😴 Quality Sleep</p>
                  <p className="text-purple-600">Get 7-9 hours of sleep each night</p>
                </div>
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <p className="font-medium text-yellow-800">🍎 Balanced Diet</p>
                  <p className="text-yellow-600">Include variety in your nutrition plan</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Health Goals */}
          <Card>
            <CardHeader>
              <CardTitle>Health Targets</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Daily Steps</span>
                  <span>{metrics?.steps || 0}/10,000</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min(((metrics?.steps || 0) / 10000) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Sleep Goal</span>
                  <span>{metrics?.sleepHours || 0}/8 hours</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-purple-500 h-2 rounded-full transition-all duration-300" 
                    style={{ width: `${Math.min(((metrics?.sleepHours || 0) / 8) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>

              {latest?.weight && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Weight Goal</span>
                    <span>{latest.weight}/65 kg</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${Math.min((65 / latest.weight) * 100, 100)}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default HealthMetricsPage;
