import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Trophy, Calendar, CheckCircle, Camera, Dumbbell, Apple, Droplets, Clock } from "lucide-react";
import { format, subDays, addDays } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ChallengeProgress } from "@shared/schema";

const Challenge = () => {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: challengeData, isLoading } = useQuery<ChallengeProgress>({
    queryKey: ['/api/challenge', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/challenge?date=${selectedDate}`);
      const data = await res.json();
      return data;
    }
  });

  const updateChallengeMutation = useMutation({
    mutationFn: async (data: { tasksCompleted: string[]; currentDay?: number }) => {
      await apiRequest('POST', '/api/challenge', {
        challengeType: '75-day',
        currentDay: challengeData?.currentDay || 1,
        totalDays: 75,
        requiredTasks: ['workout', 'diet', 'water', 'photo'],
        date: selectedDate,
        ...data
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/challenge'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Challenge updated!",
        description: "Your progress has been saved.",
      });
      setIsUpdateModalOpen(false);
    }
  });

  const currentDay = challengeData?.currentDay || 1;
  const totalDays = challengeData?.totalDays || 75;
  const progress = (currentDay / totalDays) * 100;
  const tasksCompletedToday = challengeData?.tasksCompleted || [];
  const requiredTasks = challengeData?.requiredTasks || ['workout', 'diet', 'water', 'photo'];

  const taskDetails = {
    workout: { 
      name: 'Workout', 
      description: '45 minutes of physical exercise', 
      icon: Dumbbell, 
      color: 'text-red-600 bg-red-50 border-red-200',
      completedColor: 'text-green-600 bg-green-50 border-green-200'
    },
    diet: { 
      name: 'Follow Diet', 
      description: 'Stick to your nutrition plan', 
      icon: Apple, 
      color: 'text-green-600 bg-green-50 border-green-200',
      completedColor: 'text-green-600 bg-green-50 border-green-200'
    },
    water: { 
      name: 'Water Goal', 
      description: 'Drink your daily water target', 
      icon: Droplets, 
      color: 'text-blue-600 bg-blue-50 border-blue-200',
      completedColor: 'text-green-600 bg-green-50 border-green-200'
    },
    photo: { 
      name: 'Progress Photo', 
      description: 'Take a daily progress photo', 
      icon: Camera, 
      color: 'text-purple-600 bg-purple-50 border-purple-200',
      completedColor: 'text-green-600 bg-green-50 border-green-200'
    }
  };

  const handleUpdateProgress = () => {
    setCompletedTasks(tasksCompletedToday);
    setIsUpdateModalOpen(true);
  };

  const handleSaveProgress = () => {
    updateChallengeMutation.mutate({ tasksCompleted: completedTasks });
  };

  const generateCalendarDays = () => {
    const today = new Date();
    const startDate = challengeData?.startDate ? new Date(challengeData.startDate) : subDays(today, currentDay - 1);
    const days = [];

    for (let i = 0; i < totalDays; i++) {
      const date = addDays(startDate, i);
      const dayNumber = i + 1;
      const isToday = format(date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd');
      const isPast = date < today;
      const isFuture = date > today;
      
      days.push({
        date: format(date, 'yyyy-MM-dd'),
        dayNumber,
        isToday,
        isPast,
        isFuture,
        isCompleted: dayNumber < currentDay || (dayNumber === currentDay && tasksCompletedToday.length === requiredTasks.length)
      });
    }

    return days;
  };

  const calendarDays = generateCalendarDays();

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="mb-4 lg:mb-0">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800">75-Day Hard Challenge</h2>
            <p className="text-gray-600 mt-1">Transform your life with discipline and consistency</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <p className="text-sm text-gray-600">Current Progress</p>
              <p className="text-2xl font-bold text-accent">Day {currentDay}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Progress & Tasks */}
        <div className="lg:col-span-2 space-y-6">
          {/* Progress Overview */}
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-accent" />
                <CardTitle>Challenge Progress</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="text-center p-4 bg-accent/5 rounded-lg">
                  <p className="text-3xl font-bold text-accent">{currentDay}</p>
                  <p className="text-sm text-gray-600">Current Day</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-3xl font-bold text-green-600">{Math.round(progress)}%</p>
                  <p className="text-sm text-gray-600">Complete</p>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-3xl font-bold text-blue-600">{totalDays - currentDay + 1}</p>
                  <p className="text-sm text-gray-600">Days Left</p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex justify-between text-sm mb-2">
                  <span>Overall Progress</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-4" />
                <p className="text-center text-sm text-gray-600 mt-2">
                  {progress >= 100 ? "🎉 Challenge Completed!" : `${totalDays - currentDay + 1} days remaining`}
                </p>
              </div>

              <div className="text-center">
                <p className="text-lg font-semibold text-gray-800 mb-2">
                  {challengeData?.startDate && (
                    <>Started on {format(new Date(challengeData.startDate), 'MMMM d, yyyy')}</>
                  )}
                </p>
                <p className="text-sm text-gray-600">
                  Stay committed to your daily tasks and transform your life!
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Today's Tasks */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Today's Tasks - Day {currentDay}</CardTitle>
                <Badge variant="outline" className="text-accent border-accent">
                  {tasksCompletedToday.length}/{requiredTasks.length} completed
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {requiredTasks.map((taskKey) => {
                  const task = taskDetails[taskKey as keyof typeof taskDetails];
                  const isCompleted = tasksCompletedToday.includes(taskKey);
                  const IconComponent = task.icon;
                  
                  return (
                    <div 
                      key={taskKey} 
                      className={`flex items-center justify-between p-4 rounded-lg border-2 transition-all duration-200 challenge-task ${
                        isCompleted ? task.completedColor : task.color
                      }`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          isCompleted ? 'bg-green-100' : 'bg-white'
                        }`}>
                          {isCompleted ? (
                            <CheckCircle className="w-6 h-6 text-green-600" />
                          ) : (
                            <IconComponent className="w-6 h-6" />
                          )}
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-800">{task.name}</h3>
                          <p className="text-sm text-gray-600">{task.description}</p>
                        </div>
                      </div>
                      <Badge variant={isCompleted ? "default" : "secondary"} className={
                        isCompleted ? "bg-green-100 text-green-600 hover:bg-green-100" : ""
                      }>
                        {isCompleted ? 'Completed' : 'Pending'}
                      </Badge>
                    </div>
                  );
                })}
              </div>

              <div className="mt-6 flex space-x-3">
                <Dialog open={isUpdateModalOpen} onOpenChange={setIsUpdateModalOpen}>
                  <DialogTrigger asChild>
                    <Button 
                      onClick={handleUpdateProgress}
                      className="flex-1 bg-accent hover:bg-accent/90"
                      data-testid="button-update-progress"
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Update Progress
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Update Day {currentDay} Progress</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <p className="text-sm text-gray-600">
                        Mark the tasks you've completed today:
                      </p>
                      <div className="space-y-3">
                        {requiredTasks.map((taskKey) => {
                          const task = taskDetails[taskKey as keyof typeof taskDetails];
                          const IconComponent = task.icon;
                          
                          return (
                            <div key={taskKey} className="flex items-center space-x-3">
                              <Checkbox
                                id={taskKey}
                                checked={completedTasks.includes(taskKey)}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    setCompletedTasks([...completedTasks, taskKey]);
                                  } else {
                                    setCompletedTasks(completedTasks.filter(t => t !== taskKey));
                                  }
                                }}
                                data-testid={`checkbox-${taskKey}`}
                              />
                              <div className="flex items-center space-x-2">
                                <IconComponent className="w-4 h-4" />
                                <label htmlFor={taskKey} className="text-sm font-medium">
                                  {task.name}
                                </label>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <Button 
                        onClick={handleSaveProgress}
                        disabled={updateChallengeMutation.isPending}
                        className="w-full"
                        data-testid="button-save-progress"
                      >
                        Save Progress
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
                
                {currentDay < totalDays && tasksCompletedToday.length === requiredTasks.length && (
                  <Button 
                    variant="outline"
                    onClick={() => updateChallengeMutation.mutate({ 
                      tasksCompleted: [], 
                      currentDay: currentDay + 1 
                    })}
                    data-testid="button-advance-day"
                  >
                    <Clock className="w-4 h-4 mr-2" />
                    Advance to Day {currentDay + 1}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Challenge Rules */}
          <Card>
            <CardHeader>
              <CardTitle>75 Hard Challenge Rules</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-red-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Dumbbell className="w-5 h-5 text-red-600" />
                      <h3 className="font-semibold text-red-800">Two 45-Minute Workouts</h3>
                    </div>
                    <p className="text-sm text-red-700">
                      One must be outdoors, regardless of weather conditions.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Apple className="w-5 h-5 text-green-600" />
                      <h3 className="font-semibold text-green-800">Follow a Diet</h3>
                    </div>
                    <p className="text-sm text-green-700">
                      No cheat meals or alcohol for the entire 75 days.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Droplets className="w-5 h-5 text-blue-600" />
                      <h3 className="font-semibold text-blue-800">Drink 1 Gallon of Water</h3>
                    </div>
                    <p className="text-sm text-blue-700">
                      About 3.8 liters of water daily for proper hydration.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Camera className="w-5 h-5 text-purple-600" />
                      <h3 className="font-semibold text-purple-800">Take Progress Photo</h3>
                    </div>
                    <p className="text-sm text-purple-700">
                      Daily progress photos to track your transformation.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-yellow-50 rounded-lg border-2 border-yellow-200">
                  <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Important Rule</h4>
                  <p className="text-sm text-yellow-700">
                    If you miss ANY task on ANY day, you must start over from Day 1. 
                    No exceptions, no excuses. This challenge is about building mental toughness.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Calendar View */}
        <div className="space-y-6">
          {/* Calendar */}
          <Card>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Calendar className="w-5 h-5 text-accent" />
                <CardTitle>Challenge Calendar</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 mb-4">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day) => (
                  <div key={day} className="text-center text-xs font-medium text-gray-500 p-2">
                    {day}
                  </div>
                ))}
                {calendarDays.slice(0, 35).map((day) => ( // Show first 5 weeks
                  <div
                    key={day.dayNumber}
                    className={`text-center text-xs p-2 rounded transition-colors ${
                      day.isToday
                        ? 'bg-accent text-white font-bold'
                        : day.isCompleted
                        ? 'bg-green-100 text-green-800'
                        : day.isPast
                        ? 'bg-red-100 text-red-600'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {day.dayNumber}
                  </div>
                ))}
              </div>
              <div className="text-xs text-center space-y-1">
                <div className="flex items-center justify-center space-x-4">
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-green-100 rounded"></div>
                    <span>Completed</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-accent rounded"></div>
                    <span>Today</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-gray-100 rounded"></div>
                    <span>Future</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Motivation */}
          <Card>
            <CardHeader>
              <CardTitle>💪 Daily Motivation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-100">
                  <p className="text-sm font-medium text-purple-800 mb-2">
                    "The magic happens outside your comfort zone."
                  </p>
                  <p className="text-xs text-purple-600">
                    Every day you complete is a victory. Keep pushing forward!
                  </p>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Discipline Building</span>
                    <div className="w-16 bg-gray-200 rounded-full h-2">
                      <div className="bg-accent h-2 rounded-full" style={{ width: `${Math.min(progress, 100)}%` }}></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Mental Toughness</span>
                    <div className="w-16 bg-gray-200 rounded-full h-2">
                      <div className="bg-accent h-2 rounded-full" style={{ width: `${Math.min(progress * 0.8, 100)}%` }}></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Physical Fitness</span>
                    <div className="w-16 bg-gray-200 rounded-full h-2">
                      <div className="bg-accent h-2 rounded-full" style={{ width: `${Math.min(progress * 1.2, 100)}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistics */}
          <Card>
            <CardHeader>
              <CardTitle>Challenge Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Days Completed</span>
                  <span className="font-medium">{currentDay - 1}/{totalDays}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Success Rate</span>
                  <span className="font-medium">{Math.round(((currentDay - 1) / totalDays) * 100)}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Tasks Today</span>
                  <span className="font-medium">{tasksCompletedToday.length}/{requiredTasks.length}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Days Remaining</span>
                  <span className="font-medium text-accent">{totalDays - currentDay + 1}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Challenge;
