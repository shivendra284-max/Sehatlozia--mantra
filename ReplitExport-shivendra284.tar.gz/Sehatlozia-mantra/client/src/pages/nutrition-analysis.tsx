import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { NutritionChart } from "@/components/charts/nutrition-chart";
import { BarChart, Table, Calendar, TrendingUp } from "lucide-react";
import { format, subDays, startOfWeek, endOfWeek } from "date-fns";
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import type { DailyNutrition, NutritionGoals } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const NutritionAnalysis = () => {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [viewMode, setViewMode] = useState<'daily' | 'weekly'>('daily');

  const { data: dailyNutrition, isLoading: isDailyLoading } = useQuery<DailyNutrition>({
    queryKey: ['/api/nutrition', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/nutrition/${selectedDate}`);
      return res.json();
    }
  });

  const { data: nutritionGoals, isLoading: isGoalsLoading } = useQuery<NutritionGoals>({
    queryKey: ['/api/nutrition-goals'],
    queryFn: async () => {
      const res = await fetch('/api/nutrition-goals');
      return res.json();
    }
  });

  const { data: weeklyData, isLoading: isWeeklyLoading } = useQuery({
    queryKey: ['/api/nutrition/weekly', selectedDate],
    queryFn: async () => {
      const startDate = startOfWeek(new Date(selectedDate));
      const endDate = endOfWeek(new Date(selectedDate));
      const days = [];
      
      for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dateStr = format(d, 'yyyy-MM-dd');
        const res = await fetch(`/api/nutrition/${dateStr}`);
        const nutrition = await res.json();
        days.push({
          date: dateStr,
          dayName: format(d, 'EEE'),
          ...nutrition
        });
      }
      
      return days;
    },
    enabled: viewMode === 'weekly'
  });

  if (isDailyLoading || isGoalsLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const nutrition = dailyNutrition!;
  const goals = nutritionGoals!;

  const nutritionItems = [
    { name: 'Calories', current: Math.round(nutrition.calories), goal: goals.calories, unit: '', color: 'bg-primary' },
    { name: 'Carbohydrates', current: Math.round(nutrition.carbs), goal: Math.round(goals.carbs), unit: 'g', color: 'bg-blue-500' },
    { name: 'Protein', current: Math.round(nutrition.protein), goal: Math.round(goals.protein), unit: 'g', color: 'bg-green-500' },
    { name: 'Fat', current: Math.round(nutrition.fat), goal: Math.round(goals.fat), unit: 'g', color: 'bg-yellow-500' },
    { name: 'Fiber', current: Math.round(nutrition.fiber), goal: Math.round(goals.fiber), unit: 'g', color: 'bg-purple-500' },
    { name: 'Sugar', current: Math.round(nutrition.sugar), goal: 50, unit: 'g', color: 'bg-pink-500' },
    { name: 'Sodium', current: Math.round(nutrition.sodium), goal: 2300, unit: 'mg', color: 'bg-red-500' },
  ];

  const weeklyChartData = {
    labels: weeklyData?.map(d => d.dayName) || [],
    datasets: [
      {
        label: 'Calories',
        data: weeklyData?.map(d => d.calories) || [],
        borderColor: 'hsl(158.7234 64.4068% 52.1569%)',
        backgroundColor: 'hsl(158.7234 64.4068% 52.1569% / 0.1)',
        tension: 0.3,
      },
      {
        label: 'Protein (g)',
        data: weeklyData?.map(d => d.protein) || [],
        borderColor: 'hsl(120 60% 50%)',
        backgroundColor: 'hsl(120 60% 50% / 0.1)',
        tension: 0.3,
        yAxisID: 'y1',
      }
    ],
  };

  const weeklyChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
    scales: {
      y: {
        type: 'linear' as const,
        display: true,
        position: 'left' as const,
        title: {
          display: true,
          text: 'Calories',
        },
      },
      y1: {
        type: 'linear' as const,
        display: true,
        position: 'right' as const,
        title: {
          display: true,
          text: 'Protein (g)',
        },
        grid: {
          drawOnChartArea: false,
        },
      },
    },
  };

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="mb-4 lg:mb-0">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800">Nutrition Analysis</h2>
            <p className="text-gray-600 mt-1">Detailed breakdown of your nutritional intake</p>
          </div>
          <div className="flex items-center space-x-3">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
              data-testid="input-date-picker"
            />
            <div className="flex bg-gray-100 rounded-lg p-1">
              <Button
                variant={viewMode === 'daily' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('daily')}
                data-testid="button-daily-view"
              >
                Daily
              </Button>
              <Button
                variant={viewMode === 'weekly' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('weekly')}
                data-testid="button-weekly-view"
              >
                Weekly
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview" data-testid="tab-overview">
            <BarChart className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="detailed" data-testid="tab-detailed">
            <Table className="w-4 h-4 mr-2" />
            Detailed
          </TabsTrigger>
          <TabsTrigger value="trends" data-testid="tab-trends">
            <TrendingUp className="w-4 h-4 mr-2" />
            Trends
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {viewMode === 'daily' ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Nutrition Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Macronutrient Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <NutritionChart 
                    data={{
                      carbs: nutrition.carbs,
                      protein: nutrition.protein,
                      fat: nutrition.fat
                    }}
                  />
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card>
                <CardHeader>
                  <CardTitle>Daily Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-primary/5 rounded-lg">
                      <p className="text-2xl font-bold text-primary">{Math.round(nutrition.calories)}</p>
                      <p className="text-sm text-gray-600">Calories</p>
                      <p className="text-xs text-gray-500">of {goals.calories} goal</p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">{Math.round(nutrition.protein)}g</p>
                      <p className="text-sm text-gray-600">Protein</p>
                      <p className="text-xs text-gray-500">of {Math.round(goals.protein)}g goal</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">{Math.round(nutrition.carbs)}g</p>
                      <p className="text-sm text-gray-600">Carbs</p>
                      <p className="text-xs text-gray-500">of {Math.round(goals.carbs)}g goal</p>
                    </div>
                    <div className="text-center p-4 bg-yellow-50 rounded-lg">
                      <p className="text-2xl font-bold text-yellow-600">{Math.round(nutrition.fat)}g</p>
                      <p className="text-sm text-gray-600">Fat</p>
                      <p className="text-xs text-gray-500">of {Math.round(goals.fat)}g goal</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Weekly Nutrition Trends</CardTitle>
              </CardHeader>
              <CardContent>
                {isWeeklyLoading ? (
                  <div className="h-64 flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <div className="h-64">
                    <Line data={weeklyChartData} options={weeklyChartOptions} />
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="detailed" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Nutrition Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b border-gray-200">
                      <th className="pb-3 text-sm font-medium text-gray-600">Nutrient</th>
                      <th className="pb-3 text-sm font-medium text-gray-600">Amount</th>
                      <th className="pb-3 text-sm font-medium text-gray-600">Goal</th>
                      <th className="pb-3 text-sm font-medium text-gray-600">Progress</th>
                      <th className="pb-3 text-sm font-medium text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody className="space-y-3">
                    {nutritionItems.map((nutrient) => {
                      const progress = Math.min((nutrient.current / nutrient.goal) * 100, 100);
                      const status = progress >= 90 ? 'Excellent' : progress >= 70 ? 'Good' : progress >= 50 ? 'Fair' : 'Low';
                      const statusColor = progress >= 90 ? 'text-green-600' : progress >= 70 ? 'text-blue-600' : progress >= 50 ? 'text-yellow-600' : 'text-red-600';
                      
                      return (
                        <tr key={nutrient.name} className="border-b border-gray-100">
                          <td className="py-4 text-sm font-medium text-gray-800">{nutrient.name}</td>
                          <td className="py-4 text-sm text-gray-600">{nutrient.current}{nutrient.unit}</td>
                          <td className="py-4 text-sm text-gray-600">{nutrient.goal}{nutrient.unit}</td>
                          <td className="py-4">
                            <div className="flex items-center space-x-3">
                              <div className="flex-1 bg-gray-200 rounded-full h-2 min-w-[60px]">
                                <div 
                                  className={`h-2 rounded-full nutrition-progress-bar ${nutrient.color}`} 
                                  style={{ width: `${progress}%` }}
                                ></div>
                              </div>
                              <span className="text-xs text-gray-500 min-w-[35px]">{Math.round(progress)}%</span>
                            </div>
                          </td>
                          <td className={`py-4 text-sm font-medium ${statusColor}`}>{status}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Goal Achievement</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {nutritionItems.slice(0, 4).map((nutrient) => {
                  const progress = Math.min((nutrient.current / nutrient.goal) * 100, 100);
                  return (
                    <div key={nutrient.name}>
                      <div className="flex justify-between text-sm mb-1">
                        <span>{nutrient.name}</span>
                        <span>{Math.round(progress)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Nutrition Insights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {nutrition.protein >= goals.protein * 0.9 && (
                    <div className="flex items-center p-3 bg-green-50 rounded-lg">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-sm text-green-700">Great protein intake today!</span>
                    </div>
                  )}
                  {nutrition.fiber >= goals.fiber * 0.8 && (
                    <div className="flex items-center p-3 bg-blue-50 rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                      <span className="text-sm text-blue-700">Good fiber intake for digestive health</span>
                    </div>
                  )}
                  {nutrition.calories < goals.calories * 0.7 && (
                    <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3"></div>
                      <span className="text-sm text-yellow-700">Consider eating more to meet calorie goals</span>
                    </div>
                  )}
                  {nutrition.sodium > 2000 && (
                    <div className="flex items-center p-3 bg-red-50 rounded-lg">
                      <div className="w-2 h-2 bg-red-500 rounded-full mr-3"></div>
                      <span className="text-sm text-red-700">High sodium intake - consider reducing salt</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default NutritionAnalysis;
