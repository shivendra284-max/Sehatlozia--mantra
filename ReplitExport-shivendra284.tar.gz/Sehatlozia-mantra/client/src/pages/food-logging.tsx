import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { FoodSearch } from "@/components/food/food-search";
import { Search, Plus, Trash2, Clock, Utensils } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { FoodLogWithFood } from "@shared/schema";

const FoodLogging = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: foodLogs, isLoading } = useQuery<FoodLogWithFood[]>({
    queryKey: ['/api/food-logs', selectedDate],
    queryFn: async () => {
      const res = await fetch(`/api/food-logs?date=${selectedDate}`);
      return res.json();
    }
  });

  const deleteFoodLogMutation = useMutation({
    mutationFn: async (logId: string) => {
      await apiRequest('DELETE', `/api/food-logs/${logId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/food-logs'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      toast({
        title: "Food entry deleted",
        description: "The food log has been removed from your diary.",
      });
    }
  });

  const groupedLogs = foodLogs?.reduce((acc, log) => {
    if (!acc[log.mealType]) {
      acc[log.mealType] = [];
    }
    acc[log.mealType].push(log);
    return acc;
  }, {} as Record<string, FoodLogWithFood[]>) || {};

  const mealTypes = [
    { key: 'breakfast', name: 'Breakfast', icon: '🌅' },
    { key: 'lunch', name: 'Lunch', icon: '☀️' },
    { key: 'dinner', name: 'Dinner', icon: '🌙' },
    { key: 'snack', name: 'Snacks', icon: '🍎' },
  ];

  const getMealTotal = (mealLogs: FoodLogWithFood[]) => {
    return mealLogs.reduce((total, log) => {
      return total + (log.food.calories * log.quantity);
    }, 0);
  };

  const totalCalories = Object.values(groupedLogs).flat().reduce((total, log) => {
    return total + (log.food.calories * log.quantity);
  }, 0);

  if (isLoading) {
    return (
      <div className="p-4 lg:p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          {Array(3).fill(0).map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="mb-4 lg:mb-0">
            <h2 className="text-2xl lg:text-3xl font-bold text-gray-800">Food Diary</h2>
            <p className="text-gray-600 mt-1">Track your meals and nutrition</p>
          </div>
          <div className="flex items-center space-x-3">
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
              data-testid="input-date-picker"
            />
            <Button 
              onClick={() => setIsSearchOpen(true)}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-add-food"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Food
            </Button>
          </div>
        </div>

        {/* Daily Summary */}
        <Card className="mt-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-800">Daily Total</h3>
                <p className="text-3xl font-bold text-primary">{Math.round(totalCalories)} calories</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">{format(new Date(selectedDate), 'EEEE, MMMM d')}</p>
                <p className="text-sm text-gray-500">{Object.values(groupedLogs).flat().length} items logged</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Meals */}
      <div className="space-y-6">
        {mealTypes.map((mealType) => {
          const mealLogs = groupedLogs[mealType.key] || [];
          const mealCalories = getMealTotal(mealLogs);

          return (
            <Card key={mealType.key}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{mealType.icon}</span>
                    <div>
                      <CardTitle>{mealType.name}</CardTitle>
                      <p className="text-sm text-gray-600">{Math.round(mealCalories)} calories</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsSearchOpen(true)}
                    data-testid={`button-add-${mealType.key}`}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {mealLogs.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Utensils className="w-8 h-8 mx-auto mb-2 opacity-20" />
                    <p>No {mealType.name.toLowerCase()} logged</p>
                    <p className="text-sm">Tap "Add" to log your {mealType.name.toLowerCase()}</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {mealLogs.map((log) => (
                      <div key={log.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3">
                            <div>
                              <h4 className="font-medium text-gray-800">{log.food.name}</h4>
                              {log.food.nameHindi && (
                                <p className="text-sm text-gray-500">{log.food.nameHindi}</p>
                              )}
                              <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                                <span>{Math.round(log.food.calories * log.quantity)} cal</span>
                                <span>{Math.round(log.food.carbs * log.quantity)}g carbs</span>
                                <span>{Math.round(log.food.protein * log.quantity)}g protein</span>
                                <span>{Math.round(log.food.fat * log.quantity)}g fat</span>
                              </div>
                              <div className="flex items-center space-x-2 mt-2">
                                <Badge variant="secondary" className="text-xs">
                                  {log.quantity}x {log.food.servingSize}
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {log.food.category}
                                </Badge>
                                {log.food.isIndian && (
                                  <Badge variant="outline" className="text-xs border-orange-200 text-orange-600">
                                    Indian
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="text-right">
                            <p className="text-sm text-gray-500 flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {format(new Date(log.loggedAt), 'h:mm a')}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteFoodLogMutation.mutate(log.id)}
                            disabled={deleteFoodLogMutation.isPending}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            data-testid={`button-delete-${log.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Food Search Modal */}
      <FoodSearch 
        isOpen={isSearchOpen} 
        onClose={() => setIsSearchOpen(false)} 
      />
    </div>
  );
};

export default FoodLogging;
