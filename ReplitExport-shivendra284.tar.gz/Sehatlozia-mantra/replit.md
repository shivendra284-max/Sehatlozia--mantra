# NutriTrack - Health & Wellness Tracking Application

## Overview

NutriTrack is a comprehensive health and wellness tracking application built as a full-stack web application. It allows users to track their nutrition, water intake, meditation sessions, health metrics, and participate in a 75-day challenge. The app features food logging with detailed nutritional information, progress visualization through charts, and goal-setting capabilities. It's designed with a focus on Indian foods and wellness practices while maintaining a clean, responsive interface suitable for both desktop and mobile use.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built using **React** with **TypeScript** and utilizes modern React patterns including hooks and functional components. The routing is handled by **Wouter**, a lightweight alternative to React Router. State management is handled through **TanStack Query (React Query)** for server state and local React state for UI interactions. The UI follows a component-based architecture with reusable components organized in a structured hierarchy.

**Styling and UI Framework**: The application uses **Tailwind CSS** for utility-first styling combined with **shadcn/ui** component library built on **Radix UI** primitives. This provides a consistent design system with accessible, customizable components. The design follows a "new-york" style variant with CSS variables for theming.

**Chart Visualization**: Uses **Chart.js** with React wrappers for displaying nutrition analytics and progress tracking through doughnuts, line charts, and bar charts.

### Backend Architecture
The server is built with **Express.js** and **Node.js** using TypeScript in ES Module format. It follows a RESTful API design pattern with routes organized by feature domains (foods, water intake, meditation, etc.). The server implements proper error handling middleware and request logging for development debugging.

**API Structure**: Routes are organized by resource type with standard HTTP methods (GET, POST, DELETE) and follow RESTful conventions. Each route includes proper validation using **Zod** schemas and error handling.

**Development Setup**: The application uses **Vite** for development with hot module replacement, custom middleware integration, and optimized build processes for both development and production environments.

### Data Storage Solutions
The application uses **PostgreSQL** as the primary database with **Drizzle ORM** for type-safe database operations. Database schemas are defined using Drizzle's schema definition with proper TypeScript types.

**Database Design**: The schema includes tables for foods (with Indian food support), food logs, water intake tracking, meditation sessions, health metrics, goals, challenge progress, and nutrition goals. All tables use UUID primary keys and include proper relationships and constraints.

**Migration Strategy**: Database migrations are managed through Drizzle Kit with a dedicated migrations directory for version control of schema changes.

### Authentication and Authorization
The current architecture supports session-based authentication through **connect-pg-simple** for PostgreSQL session storage, though specific authentication routes and middleware are not fully implemented in the visible codebase.

### External Dependencies

**Database and ORM**:
- **Neon Database** (@neondatabase/serverless) for PostgreSQL hosting
- **Drizzle ORM** with PostgreSQL dialect for type-safe database operations
- **connect-pg-simple** for PostgreSQL session storage

**UI and Styling**:
- **Radix UI** components for accessible, unstyled UI primitives
- **Tailwind CSS** for utility-first styling
- **shadcn/ui** component system with customizable design tokens
- **Lucide React** for consistent iconography

**Form Handling and Validation**:
- **React Hook Form** for performant form management
- **Zod** for runtime type validation and schema definition
- **@hookform/resolvers** for Zod integration

**Data Visualization**:
- **Chart.js** with React wrappers for nutrition and progress charts
- **Embla Carousel** for mobile-friendly content sliders

**Development Tools**:
- **Vite** for fast development and optimized builds
- **ESBuild** for production server bundling
- **TypeScript** for type safety across frontend and backend
- **Replit** specific plugins for development environment integration

**Utility Libraries**:
- **date-fns** for date manipulation and formatting
- **class-variance-authority** for conditional CSS class management
- **clsx** and **tailwind-merge** for dynamic className handling
- **nanoid** for generating unique identifiers