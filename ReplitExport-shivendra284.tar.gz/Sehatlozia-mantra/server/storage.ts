import { randomUUID } from "crypto";
import type { 
  Food, 
  InsertFood, 
  FoodLog, 
  InsertFoodLog, 
  FoodLogWithFood,
  WaterIntake,
  InsertWaterIntake,
  MeditationSession,
  InsertMeditationSession,
  HealthMetrics,
  InsertHealthMetrics,
  Goal,
  InsertGoal,
  ChallengeProgress,
  InsertChallengeProgress,
  NutritionGoals,
  InsertNutritionGoals,
  DailyNutrition
} from "@shared/schema";

export interface IStorage {
  // Foods
  getFoods(): Promise<Food[]>;
  searchFoods(query: string): Promise<Food[]>;
  getFood(id: string): Promise<Food | undefined>;
  createFood(insertFood: InsertFood): Promise<Food>;

  // Food Logs  
  getFoodLogs(date?: string): Promise<FoodLogWithFood[]>;
  createFoodLog(insertFoodLog: InsertFoodLog): Promise<FoodLog>;
  deleteFoodLog(id: string): Promise<boolean>;

  // Water Intake
  getWaterIntake(date?: string): Promise<WaterIntake[]>;
  createWaterIntake(insertWaterIntake: InsertWaterIntake): Promise<WaterIntake>;
  deleteWaterIntake(id: string): Promise<boolean>;

  // Meditation Sessions
  getMeditationSessions(date?: string): Promise<MeditationSession[]>;
  createMeditationSession(insertMeditationSession: InsertMeditationSession): Promise<MeditationSession>;
  deleteMeditationSession(id: string): Promise<boolean>;

  // Health Metrics
  getHealthMetrics(date?: string): Promise<HealthMetrics[]>;
  getLatestHealthMetrics(): Promise<HealthMetrics | undefined>;
  createHealthMetrics(insertHealthMetrics: InsertHealthMetrics): Promise<HealthMetrics>;

  // Goals
  getGoals(): Promise<Goal[]>;
  getGoal(id: string): Promise<Goal | undefined>;
  createGoal(insertGoal: InsertGoal): Promise<Goal>;
  updateGoal(id: string, updateData: Partial<Goal>): Promise<Goal | undefined>;
  deleteGoal(id: string): Promise<boolean>;

  // Challenge Progress
  getChallengeProgress(date?: string): Promise<ChallengeProgress[]>;
  createChallengeProgress(insertChallengeProgress: InsertChallengeProgress): Promise<ChallengeProgress>;
  updateChallengeProgress(id: string, updateData: Partial<ChallengeProgress>): Promise<ChallengeProgress | undefined>;

  // Nutrition Goals
  getNutritionGoals(): Promise<NutritionGoals | undefined>;
  createOrUpdateNutritionGoals(insertNutritionGoals: InsertNutritionGoals): Promise<NutritionGoals>;

  // Daily Nutrition
  getDailyNutrition(date: string): Promise<DailyNutrition>;
}

export class MemStorage implements IStorage {
  private foods = new Map<string, Food>();
  private foodLogs = new Map<string, FoodLog>();
  private waterIntakes = new Map<string, WaterIntake>();
  private meditationSessions = new Map<string, MeditationSession>();
  private healthMetrics = new Map<string, HealthMetrics>();
  private goals = new Map<string, Goal>();
  private challengeProgress = new Map<string, ChallengeProgress>();
  private nutritionGoals: NutritionGoals | undefined;

  constructor() {
    this.seedIndianFoods();
    this.seedNutritionGoals();
  }

  private seedNutritionGoals() {
    this.nutritionGoals = {
      id: randomUUID(),
      calories: 2000,
      carbs: 250,
      protein: 50,
      fat: 70,
      fiber: 25,
      water: 2000,
      updatedAt: new Date()
    };
  }

  private seedIndianFoods() {
    const indianFoods = [
      // Rice and Grain Dishes
      { name: "Rajma Chawal", nameHindi: "राजमा चावल", category: "Rice Dishes", servingSize: "1 bowl", calories: 420, carbs: 65, protein: 18, fat: 8, fiber: 12, sugar: 3, sodium: 580, isIndian: true },
      { name: "Dal Chawal", nameHindi: "दाल चावल", category: "Rice Dishes", servingSize: "1 bowl", calories: 350, carbs: 58, protein: 15, fat: 6, fiber: 8, sugar: 2, sodium: 420, isIndian: true },
      { name: "Biryani", nameHindi: "बिरयानी", category: "Rice Dishes", servingSize: "1 plate", calories: 680, carbs: 85, protein: 25, fat: 22, fiber: 4, sugar: 6, sodium: 890, isIndian: true },
      { name: "Pulao", nameHindi: "पुलाव", category: "Rice Dishes", servingSize: "1 bowl", calories: 380, carbs: 55, protein: 12, fat: 12, fiber: 3, sugar: 4, sodium: 650, isIndian: true },
      
      // Breads and Flatbreads
      { name: "Roti", nameHindi: "रोटी", category: "Breads", servingSize: "1 piece", calories: 71, carbs: 15, protein: 3, fat: 0.4, fiber: 2, sugar: 0.2, sodium: 2, isIndian: true },
      { name: "Naan", nameHindi: "नान", category: "Breads", servingSize: "1 piece", calories: 262, carbs: 45, protein: 9, fat: 5, fiber: 2, sugar: 3, sodium: 430, isIndian: true },
      { name: "Paratha", nameHindi: "पराठा", category: "Breads", servingSize: "1 piece", calories: 200, carbs: 24, protein: 6, fat: 9, fiber: 3, sugar: 1, sodium: 320, isIndian: true },
      { name: "Puri", nameHindi: "पूरी", category: "Breads", servingSize: "1 piece", calories: 36, carbs: 3.5, protein: 1, fat: 2.3, fiber: 0.2, sugar: 0.1, sodium: 54, isIndian: true },
      
      // Dals and Curries
      { name: "Dal Tadka", nameHindi: "दाल तड़का", category: "Dals", servingSize: "1 bowl (150ml)", calories: 180, carbs: 25, protein: 12, fat: 4, fiber: 8, sugar: 2, sodium: 420, isIndian: true },
      { name: "Chole", nameHindi: "छोले", category: "Curries", servingSize: "1 bowl (150g)", calories: 210, carbs: 35, protein: 11, fat: 4, fiber: 10, sugar: 6, sodium: 680, isIndian: true },
      { name: "Palak Paneer", nameHindi: "पालक पनीर", category: "Curries", servingSize: "1 bowl (150g)", calories: 280, carbs: 12, protein: 15, fat: 20, fiber: 4, sugar: 6, sodium: 590, isIndian: true },
      { name: "Aloo Gobi", nameHindi: "आलू गोभी", category: "Curries", servingSize: "1 bowl (150g)", calories: 160, carbs: 28, protein: 5, fat: 4, fiber: 5, sugar: 6, sodium: 420, isIndian: true },
      
      // Snacks
      { name: "Samosa", nameHindi: "समोसा", category: "Snacks", servingSize: "1 piece", calories: 170, carbs: 21, protein: 3, fat: 8, fiber: 2, sugar: 1, sodium: 420, isIndian: true },
      { name: "Dhokla", nameHindi: "ढोकला", category: "Snacks", servingSize: "2 pieces", calories: 135, carbs: 25, protein: 4, fat: 2, fiber: 2, sugar: 3, sodium: 380, isIndian: true },
      { name: "Pakora", nameHindi: "पकौड़ा", category: "Snacks", servingSize: "4 pieces", calories: 200, carbs: 18, protein: 6, fat: 12, fiber: 2, sugar: 2, sodium: 320, isIndian: true },
      { name: "Kachori", nameHindi: "कचौरी", category: "Snacks", servingSize: "1 piece", calories: 190, carbs: 20, protein: 4, fat: 11, fiber: 3, sugar: 1, sodium: 380, isIndian: true },
      
      // Sweets
      { name: "Gulab Jamun", nameHindi: "गुलाब जामुन", category: "Sweets", servingSize: "1 piece", calories: 112, carbs: 15, protein: 2, fat: 5, fiber: 0, sugar: 12, sodium: 45, isIndian: true },
      { name: "Rasgulla", nameHindi: "रसगुल्ला", category: "Sweets", servingSize: "1 piece", calories: 106, carbs: 18, protein: 4, fat: 2, fiber: 0, sugar: 16, sodium: 25, isIndian: true },
      { name: "Kheer", nameHindi: "खीर", category: "Sweets", servingSize: "1 bowl (100g)", calories: 180, carbs: 28, protein: 6, fat: 5, fiber: 0, sugar: 20, sodium: 60, isIndian: true },
      { name: "Ladoo", nameHindi: "लड्डू", category: "Sweets", servingSize: "1 piece", calories: 150, carbs: 20, protein: 3, fat: 7, fiber: 1, sugar: 15, sodium: 25, isIndian: true },
      
      // Beverages
      { name: "Lassi", nameHindi: "लस्सी", category: "Beverages", servingSize: "1 glass (200ml)", calories: 140, carbs: 18, protein: 6, fat: 4, fiber: 0, sugar: 16, sodium: 85, isIndian: true },
      { name: "Chai", nameHindi: "चाय", category: "Beverages", servingSize: "1 cup (150ml)", calories: 60, carbs: 8, protein: 2, fat: 2, fiber: 0, sugar: 6, sodium: 15, isIndian: true },
      { name: "Buttermilk", nameHindi: "छाछ", category: "Beverages", servingSize: "1 glass (200ml)", calories: 90, carbs: 12, protein: 4, fat: 2, fiber: 0, sugar: 10, sodium: 380, isIndian: true },
    ];

    indianFoods.forEach(food => {
      const id = randomUUID();
      this.foods.set(id, { ...food, id });
    });
  }

  async getFoods(): Promise<Food[]> {
    return Array.from(this.foods.values());
  }

  async searchFoods(query: string): Promise<Food[]> {
    const foods = Array.from(this.foods.values());
    const searchTerm = query.toLowerCase();
    return foods.filter(food => 
      food.name.toLowerCase().includes(searchTerm) ||
      food.nameHindi?.toLowerCase().includes(searchTerm) ||
      food.category.toLowerCase().includes(searchTerm)
    );
  }

  async getFood(id: string): Promise<Food | undefined> {
    return this.foods.get(id);
  }

  async createFood(insertFood: InsertFood): Promise<Food> {
    const id = randomUUID();
    const food: Food = { 
      ...insertFood, 
      id,
      nameHindi: insertFood.nameHindi || null,
      servingSize: insertFood.servingSize || "1 serving",
      sugar: insertFood.sugar || 0,
      sodium: insertFood.sodium || 0,
      isIndian: insertFood.isIndian || false
    };
    this.foods.set(id, food);
    return food;
  }

  async getFoodLogs(date?: string): Promise<FoodLogWithFood[]> {
    const logs = Array.from(this.foodLogs.values());
    const filteredLogs = date 
      ? logs.filter(log => log.loggedAt.toISOString().split('T')[0] === date)
      : logs;

    const result: FoodLogWithFood[] = [];
    for (const log of filteredLogs) {
      const food = this.foods.get(log.foodId);
      if (food) {
        result.push({ ...log, food });
      }
    }
    return result.sort((a, b) => b.loggedAt.getTime() - a.loggedAt.getTime());
  }

  async createFoodLog(insertFoodLog: InsertFoodLog): Promise<FoodLog> {
    const id = randomUUID();
    const foodLog: FoodLog = { 
      ...insertFoodLog, 
      id,
      quantity: insertFoodLog.quantity || 1,
      loggedAt: insertFoodLog.loggedAt || new Date()
    };
    this.foodLogs.set(id, foodLog);
    return foodLog;
  }

  async deleteFoodLog(id: string): Promise<boolean> {
    return this.foodLogs.delete(id);
  }

  async getWaterIntake(date?: string): Promise<WaterIntake[]> {
    const intakes = Array.from(this.waterIntakes.values());
    if (!date) return intakes.sort((a, b) => b.loggedAt.getTime() - a.loggedAt.getTime());
    
    return intakes
      .filter(intake => intake.date === date)
      .sort((a, b) => b.loggedAt.getTime() - a.loggedAt.getTime());
  }

  async createWaterIntake(insertWaterIntake: InsertWaterIntake): Promise<WaterIntake> {
    const id = randomUUID();
    const waterIntake: WaterIntake = {
      ...insertWaterIntake,
      id,
      loggedAt: insertWaterIntake.loggedAt || new Date()
    };
    this.waterIntakes.set(id, waterIntake);
    return waterIntake;
  }

  async deleteWaterIntake(id: string): Promise<boolean> {
    return this.waterIntakes.delete(id);
  }

  async getMeditationSessions(date?: string): Promise<MeditationSession[]> {
    const sessions = Array.from(this.meditationSessions.values());
    if (!date) return sessions.sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
    
    return sessions
      .filter(session => session.date === date)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  async createMeditationSession(insertMeditationSession: InsertMeditationSession): Promise<MeditationSession> {
    const id = randomUUID();
    const session: MeditationSession = {
      ...insertMeditationSession,
      id,
      sessionType: insertMeditationSession.sessionType || "mindfulness",
      notes: insertMeditationSession.notes || null,
      completedAt: insertMeditationSession.completedAt || new Date()
    };
    this.meditationSessions.set(id, session);
    return session;
  }

  async deleteMeditationSession(id: string): Promise<boolean> {
    return this.meditationSessions.delete(id);
  }

  async getHealthMetrics(date?: string): Promise<HealthMetrics[]> {
    const metrics = Array.from(this.healthMetrics.values());
    if (!date) return metrics.sort((a, b) => b.recordedAt.getTime() - a.recordedAt.getTime());
    
    return metrics
      .filter(metric => metric.date === date)
      .sort((a, b) => b.recordedAt.getTime() - a.recordedAt.getTime());
  }

  async getLatestHealthMetrics(): Promise<HealthMetrics | undefined> {
    const metrics = Array.from(this.healthMetrics.values());
    return metrics.sort((a, b) => b.recordedAt.getTime() - a.recordedAt.getTime())[0];
  }

  async createHealthMetrics(insertHealthMetrics: InsertHealthMetrics): Promise<HealthMetrics> {
    const id = randomUUID();
    const metrics: HealthMetrics = {
      ...insertHealthMetrics,
      id,
      height: insertHealthMetrics.height || null,
      weight: insertHealthMetrics.weight || null,
      steps: insertHealthMetrics.steps || null,
      sleepHours: insertHealthMetrics.sleepHours || null,
      bloodPressureSystolic: insertHealthMetrics.bloodPressureSystolic || null,
      bloodPressureDiastolic: insertHealthMetrics.bloodPressureDiastolic || null,
      heartRate: insertHealthMetrics.heartRate || null,
      recordedAt: new Date()
    };
    this.healthMetrics.set(id, metrics);
    return metrics;
  }

  async getGoals(): Promise<Goal[]> {
    return Array.from(this.goals.values()).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getGoal(id: string): Promise<Goal | undefined> {
    return this.goals.get(id);
  }

  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    const id = randomUUID();
    const goal: Goal = {
      ...insertGoal,
      id,
      description: insertGoal.description || null,
      currentValue: insertGoal.currentValue || 0,
      targetDate: insertGoal.targetDate || null,
      isActive: insertGoal.isActive !== undefined ? insertGoal.isActive : true,
      createdAt: new Date()
    };
    this.goals.set(id, goal);
    return goal;
  }

  async updateGoal(id: string, updateData: Partial<Goal>): Promise<Goal | undefined> {
    const goal = this.goals.get(id);
    if (!goal) return undefined;

    const updatedGoal = { ...goal, ...updateData };
    this.goals.set(id, updatedGoal);
    return updatedGoal;
  }

  async deleteGoal(id: string): Promise<boolean> {
    return this.goals.delete(id);
  }

  async getChallengeProgress(date?: string): Promise<ChallengeProgress[]> {
    const progress = Array.from(this.challengeProgress.values());
    if (!date) return progress.sort((a, b) => b.lastUpdated.getTime() - a.lastUpdated.getTime());
    
    return progress
      .filter(p => p.date === date)
      .sort((a, b) => b.lastUpdated.getTime() - a.lastUpdated.getTime());
  }

  async createChallengeProgress(insertChallengeProgress: InsertChallengeProgress): Promise<ChallengeProgress> {
    const id = randomUUID();
    const progress: ChallengeProgress = {
      ...insertChallengeProgress,
      id,
      challengeType: insertChallengeProgress.challengeType || "75-day",
      currentDay: insertChallengeProgress.currentDay || 1,
      totalDays: insertChallengeProgress.totalDays || 75,
      tasksCompleted: insertChallengeProgress.tasksCompleted || [],
      requiredTasks: insertChallengeProgress.requiredTasks || ["workout", "diet", "water", "photo"],
      startDate: insertChallengeProgress.startDate || new Date(),
      lastUpdated: new Date()
    };
    this.challengeProgress.set(id, progress);
    return progress;
  }

  async updateChallengeProgress(id: string, updateData: Partial<ChallengeProgress>): Promise<ChallengeProgress | undefined> {
    const progress = this.challengeProgress.get(id);
    if (!progress) return undefined;

    const updated = { ...progress, ...updateData, lastUpdated: new Date() };
    this.challengeProgress.set(id, updated);
    return updated;
  }

  async getNutritionGoals(): Promise<NutritionGoals | undefined> {
    return this.nutritionGoals;
  }

  async createOrUpdateNutritionGoals(insertNutritionGoals: InsertNutritionGoals): Promise<NutritionGoals> {
    if (this.nutritionGoals) {
      this.nutritionGoals = {
        ...this.nutritionGoals,
        ...insertNutritionGoals,
        updatedAt: new Date()
      };
    } else {
      this.nutritionGoals = {
        ...insertNutritionGoals,
        id: randomUUID(),
        updatedAt: new Date()
      };
    }
    return this.nutritionGoals;
  }

  async getDailyNutrition(date: string): Promise<DailyNutrition> {
    const foodLogs = await this.getFoodLogs(date);
    
    const totals = foodLogs.reduce((acc, log) => {
      const multiplier = log.quantity || 1;
      return {
        calories: acc.calories + (log.food.calories * multiplier),
        carbs: acc.carbs + (log.food.carbs * multiplier),
        protein: acc.protein + (log.food.protein * multiplier),
        fat: acc.fat + (log.food.fat * multiplier),
        fiber: acc.fiber + (log.food.fiber * multiplier),
        sugar: acc.sugar + (log.food.sugar * multiplier),
        sodium: acc.sodium + (log.food.sodium * multiplier),
      };
    }, {
      calories: 0,
      carbs: 0,
      protein: 0,
      fat: 0,
      fiber: 0,
      sugar: 0,
      sodium: 0,
    });

    return {
      ...totals,
    };
  }
}

export const storage = new MemStorage();