import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertFoodSchema, insertFoodLogSchema, insertWaterIntakeSchema, 
  insertMeditationSessionSchema, insertHealthMetricsSchema, insertGoalSchema,
  insertChallengeProgressSchema, insertNutritionGoalsSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Foods
  app.get("/api/foods", async (req, res) => {
    try {
      const { search } = req.query;
      const foods = search 
        ? await storage.searchFoods(search as string)
        : await storage.getFoods();
      res.json(foods);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch foods" });
    }
  });

  app.get("/api/foods/:id", async (req, res) => {
    try {
      const food = await storage.getFood(req.params.id);
      if (!food) {
        return res.status(404).json({ error: "Food not found" });
      }
      res.json(food);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch food" });
    }
  });

  app.post("/api/foods", async (req, res) => {
    try {
      const validatedFood = insertFoodSchema.parse(req.body);
      const food = await storage.createFood(validatedFood);
      res.status(201).json(food);
    } catch (error) {
      res.status(400).json({ error: "Invalid food data" });
    }
  });

  // Food Logs
  app.get("/api/food-logs", async (req, res) => {
    try {
      const { date } = req.query;
      const logs = await storage.getFoodLogs(date as string);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch food logs" });
    }
  });

  app.post("/api/food-logs", async (req, res) => {
    try {
      const validatedLog = insertFoodLogSchema.parse(req.body);
      const log = await storage.createFoodLog(validatedLog);
      res.status(201).json(log);
    } catch (error) {
      res.status(400).json({ error: "Invalid food log data" });
    }
  });

  app.delete("/api/food-logs/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteFoodLog(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Food log not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete food log" });
    }
  });

  app.get("/api/nutrition/:date", async (req, res) => {
    try {
      const nutrition = await storage.getDailyNutrition(req.params.date);
      res.json(nutrition);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch daily nutrition" });
    }
  });

  // Water Intake
  app.get("/api/water-intake/:date", async (req, res) => {
    try {
      const intakes = await storage.getWaterIntake(req.params.date);
      const total = intakes.reduce((sum, intake) => sum + intake.amount, 0);
      res.json({ intakes, total });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch water intake" });
    }
  });

  app.post("/api/water-intake", async (req, res) => {
    try {
      const validatedIntake = insertWaterIntakeSchema.parse(req.body);
      const intake = await storage.createWaterIntake(validatedIntake);
      res.status(201).json(intake);
    } catch (error) {
      res.status(400).json({ error: "Invalid water intake data" });
    }
  });

  // Meditation
  app.get("/api/meditation", async (req, res) => {
    try {
      const { date } = req.query;
      const sessions = await storage.getMeditationSessions(date as string);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch meditation sessions" });
    }
  });

  app.post("/api/meditation", async (req, res) => {
    try {
      const validatedSession = insertMeditationSessionSchema.parse(req.body);
      const session = await storage.createMeditationSession(validatedSession);
      res.status(201).json(session);
    } catch (error) {
      res.status(400).json({ error: "Invalid meditation session data" });
    }
  });

  app.get("/api/meditation/total/:date", async (req, res) => {
    try {
      const sessions = await storage.getMeditationSessions(req.params.date);
      const total = sessions.reduce((sum, session) => sum + session.duration, 0);
      res.json({ total });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch meditation total" });
    }
  });

  app.get("/api/meditation/streak", async (req, res) => {
    try {
      // Simple implementation - can be enhanced later
      const sessions = await storage.getMeditationSessions();
      const streak = sessions.length > 0 ? 1 : 0;
      res.json({ streak });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch meditation streak" });
    }
  });

  // Health Metrics
  app.get("/api/health-metrics", async (req, res) => {
    try {
      const { date } = req.query;
      const metrics = await storage.getHealthMetrics(date as string);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch health metrics" });
    }
  });

  app.post("/api/health-metrics", async (req, res) => {
    try {
      const validatedMetrics = insertHealthMetricsSchema.parse(req.body);
      const metrics = await storage.createHealthMetrics(validatedMetrics);
      res.status(201).json(metrics);
    } catch (error) {
      res.status(400).json({ error: "Invalid health metrics data" });
    }
  });

  app.get("/api/health-metrics/latest", async (req, res) => {
    try {
      const metrics = await storage.getLatestHealthMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch latest health metrics" });
    }
  });

  // Goals
  app.get("/api/goals", async (req, res) => {
    try {
      const goals = await storage.getGoals();
      res.json(goals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch goals" });
    }
  });

  app.post("/api/goals", async (req, res) => {
    try {
      const validatedGoal = insertGoalSchema.parse(req.body);
      const goal = await storage.createGoal(validatedGoal);
      res.status(201).json(goal);
    } catch (error) {
      res.status(400).json({ error: "Invalid goal data" });
    }
  });

  app.patch("/api/goals/:id", async (req, res) => {
    try {
      const goal = await storage.updateGoal(req.params.id, req.body);
      if (!goal) {
        return res.status(404).json({ error: "Goal not found" });
      }
      res.json(goal);
    } catch (error) {
      res.status(500).json({ error: "Failed to update goal" });
    }
  });

  app.delete("/api/goals/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteGoal(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Goal not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete goal" });
    }
  });

  // Challenge Progress
  app.get("/api/challenge", async (req, res) => {
    try {
      const { date } = req.query;
      const progress = await storage.getChallengeProgress(date as string);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch challenge progress" });
    }
  });

  app.post("/api/challenge", async (req, res) => {
    try {
      const validatedProgress = insertChallengeProgressSchema.parse(req.body);
      const progress = await storage.createChallengeProgress(validatedProgress);
      res.status(201).json(progress);
    } catch (error) {
      res.status(400).json({ error: "Invalid challenge progress data" });
    }
  });

  // Nutrition Goals
  app.get("/api/nutrition-goals", async (req, res) => {
    try {
      const goals = await storage.getNutritionGoals();
      res.json(goals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch nutrition goals" });
    }
  });

  app.patch("/api/nutrition-goals", async (req, res) => {
    try {
      const validatedGoals = insertNutritionGoalsSchema.parse(req.body);
      const goals = await storage.createOrUpdateNutritionGoals(validatedGoals);
      res.json(goals);
    } catch (error) {
      res.status(400).json({ error: "Invalid nutrition goals data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
