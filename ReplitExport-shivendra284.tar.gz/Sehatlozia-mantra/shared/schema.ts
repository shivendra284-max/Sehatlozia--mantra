import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const foods = pgTable("foods", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  nameHindi: text("name_hindi"),
  category: text("category").notNull(),
  servingSize: text("serving_size").notNull().default("1 serving"),
  calories: real("calories").notNull(),
  carbs: real("carbs").notNull().default(0),
  protein: real("protein").notNull().default(0),
  fat: real("fat").notNull().default(0),
  fiber: real("fiber").notNull().default(0),
  sugar: real("sugar").notNull().default(0),
  sodium: real("sodium").notNull().default(0),
  isIndian: boolean("is_indian").notNull().default(true),
});

export const foodLogs = pgTable("food_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  foodId: varchar("food_id").references(() => foods.id).notNull(),
  quantity: real("quantity").notNull().default(1),
  mealType: text("meal_type").notNull(), // breakfast, lunch, dinner, snack
  loggedAt: timestamp("logged_at").defaultNow().notNull(),
});

export const waterIntake = pgTable("water_intake", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  amount: real("amount").notNull(), // in ml
  loggedAt: timestamp("logged_at").defaultNow().notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format
});

export const meditationSessions = pgTable("meditation_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  duration: integer("duration").notNull(), // in minutes
  sessionType: text("session_type").notNull().default("guided"),
  notes: text("notes"),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format
});

export const healthMetrics = pgTable("health_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  weight: real("weight"), // in kg
  height: real("height"), // in cm
  steps: integer("steps"),
  sleepHours: real("sleep_hours"),
  bloodPressureSystolic: integer("bp_systolic"),
  bloodPressureDiastolic: integer("bp_diastolic"),
  heartRate: integer("heart_rate"),
  recordedAt: timestamp("recorded_at").defaultNow().notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format
});

export const goals = pgTable("goals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  targetValue: real("target_value").notNull(),
  currentValue: real("current_value").notNull().default(0),
  unit: text("unit").notNull(), // kg, calories, minutes, glasses, etc.
  category: text("category").notNull(), // weight, nutrition, fitness, meditation
  targetDate: timestamp("target_date"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const challengeProgress = pgTable("challenge_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  challengeType: text("challenge_type").notNull().default("75-day"),
  currentDay: integer("current_day").notNull().default(1),
  totalDays: integer("total_days").notNull().default(75),
  tasksCompleted: jsonb("tasks_completed").$type<string[]>().notNull().default([]),
  requiredTasks: jsonb("required_tasks").$type<string[]>().notNull().default(["workout", "diet", "water", "photo"]),
  startDate: timestamp("start_date").defaultNow().notNull(),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format
});

export const nutritionGoals = pgTable("nutrition_goals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  calories: real("calories").notNull().default(2000),
  carbs: real("carbs").notNull().default(250), // in grams
  protein: real("protein").notNull().default(50), // in grams
  fat: real("fat").notNull().default(70), // in grams
  fiber: real("fiber").notNull().default(25), // in grams
  water: real("water").notNull().default(2000), // in ml
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Insert schemas
export const insertFoodSchema = createInsertSchema(foods).omit({ id: true });
export const insertFoodLogSchema = createInsertSchema(foodLogs).omit({ id: true });
export const insertWaterIntakeSchema = createInsertSchema(waterIntake).omit({ id: true });
export const insertMeditationSessionSchema = createInsertSchema(meditationSessions).omit({ id: true });
export const insertHealthMetricsSchema = createInsertSchema(healthMetrics).omit({ id: true });
export const insertGoalSchema = createInsertSchema(goals).omit({ id: true });
export const insertChallengeProgressSchema = createInsertSchema(challengeProgress).omit({ id: true });
export const insertNutritionGoalsSchema = createInsertSchema(nutritionGoals).omit({ id: true });

// Types
export type InsertFood = z.infer<typeof insertFoodSchema>;
export type Food = typeof foods.$inferSelect;
export type InsertFoodLog = z.infer<typeof insertFoodLogSchema>;
export type FoodLog = typeof foodLogs.$inferSelect;
export type InsertWaterIntake = z.infer<typeof insertWaterIntakeSchema>;
export type WaterIntake = typeof waterIntake.$inferSelect;
export type InsertMeditationSession = z.infer<typeof insertMeditationSessionSchema>;
export type MeditationSession = typeof meditationSessions.$inferSelect;
export type InsertHealthMetrics = z.infer<typeof insertHealthMetricsSchema>;
export type HealthMetrics = typeof healthMetrics.$inferSelect;
export type InsertGoal = z.infer<typeof insertGoalSchema>;
export type Goal = typeof goals.$inferSelect;
export type InsertChallengeProgress = z.infer<typeof insertChallengeProgressSchema>;
export type ChallengeProgress = typeof challengeProgress.$inferSelect;
export type InsertNutritionGoals = z.infer<typeof insertNutritionGoalsSchema>;
export type NutritionGoals = typeof nutritionGoals.$inferSelect;

// Extended types for API responses
export type FoodLogWithFood = FoodLog & { food: Food };
export type DailyNutrition = {
  calories: number;
  carbs: number;
  protein: number;
  fat: number;
  fiber: number;
  sugar: number;
  sodium: number;
};
